import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// API Routes
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// "Ask the Placement Data" AI Endpoint
app.post("/api/ask-data", async (req, res) => {
  const { question, contextSummary } = req.body;

  if (!question) {
    return res.status(400).json({ error: "Question is required" });
  }

  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    // Return rule-based fallback response if Gemini key is not configured
    return res.json({
      answer: getRuleBasedAnswer(question, contextSummary),
      source: "local-rules",
      isFallback: true
    });
  }

  try {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });

    const prompt = `You are the Placement Decision Support System Assistant for Development Management Institute (DMI), Patna.
Your job is to provide concise, evidence-based, analytical insights on placement outcomes, employer demand, skill gaps, interview rejections, and recruiter trends based on institutional placement data.

Institutional Context:
- Institution: Development Management Institute (DMI), Patna (autonomous institute under Govt of Bihar initiative).
- Programme: PG Programme in Development Management (PDM).
- Current Active Batch: PDM 12 (2025–26) with 50 eligible candidates.
- Context Data Summary: ${JSON.stringify(contextSummary || {})}

Question asked by Placement Officer / Leadership: "${question}"

Instructions:
1. Provide a sharp, executive 2-3 paragraph answer focusing on diagnostic findings and strategic recommendations.
2. Use bullet points for key data highlights.
3. Explicitly state whether findings reflect current demo data trends or institutional recommendations.
4. Keep tone professional, academic, and decision-focused.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
    });

    const answer = response.text || "No response generated.";
    return res.json({ answer, source: "gemini-3.6-flash" });
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    return res.json({
      answer: getRuleBasedAnswer(question, contextSummary),
      source: "local-rules-fallback",
      error: error.message
    });
  }
});

function getRuleBasedAnswer(q: string, context: any): string {
  const query = q.toLowerCase();
  
  if (query.includes("conversion") || query.includes("decline") || query.includes("interview")) {
    return `**Interview Conversion Diagnostics:**\n\n- The overall interview-to-offer conversion rate stands at **32%** for the current batch.\n- Primary bottlenecks occur during technical and analytical case rounds in NGOs and CSR organisations.\n- **Top Rejection Drivers:** Communication proficiency (32% of rejections) and Excel/Analytical Case capability (24% of rejections).\n- **Recommended Action:** Conduct mock case-interview bootcamps and targeted verbal presentation workshops before Phase 2 campus drives.`;
  }
  
  if (query.includes("skill") || query.includes("gap") || query.includes("demand")) {
    return `**Skill Demand & Gap Analysis:**\n\n- The highest employer demand skills are **Communication (4.7/5)**, **Excel (4.5/5)**, **Project Management (4.4/5)**, and **Data Analysis (4.2/5)**.\n- **Largest Skill Gaps Identified:**\n  1. Advanced Excel & Financial Modeling (-1.3 gap)\n  2. Communication & Pitching (-1.1 gap)\n  3. Data Analysis & Power BI (-1.1 gap)\n- **Priority Intervention Index:** Excel and Data Analysis score as Tier-1 High Priority for immediate curriculum alignment.`;
  }

  if (query.includes("recruiter") || query.includes("prioritize") || query.includes("partner")) {
    return `**Recruiter Intelligence Strategy:**\n\n- **Strategic Partners (High Relationship + High Potential):** JEEViKA (BRLPS), Aga Khan Rural Support Programme, TechnoServe, CARE India, COMFED.\n- **Growth Opportunities (High Potential, Low Current Volume):** Tata Trusts, Quest Alliance, Digital Green.\n- **Repeat Recruiter Rate:** Currently at **61%**.\n- **Key Recommendation:** Establish dedicated account managers in the Placement Cell for top 10 repeat development-sector partners to lock in pre-placement offers (PPOs).`;
  }

  if (query.includes("sector") || query.includes("growing") || query.includes("trend")) {
    return `**Development Sector Hiring Trends:**\n\n- **Fastest Growing Sectors:** Livelihoods (+18% YoY), Climate & Sustainability (+25% YoY), Data/Digital Development (+30% YoY).\n- **Highest Average CTC Sectors:** Research & Consulting (₹9.8 LPA) and Financial Inclusion (₹8.9 LPA).\n- **Emerging Demand:** High increase in roles requiring M&E and GIS/data mapping combined with rural field exposure.`;
  }

  if (query.includes("elective") || query.includes("curriculum") || query.includes("course")) {
    return `**Curriculum & Course Alignment:**\n\n- **Top Aligned Electives:** Big Data & Business Intelligence (91% alignment), Monitoring & Evaluation (88% alignment), Project Management (85% alignment).\n- **Gap Area:** Courses need stronger practical integration with Power BI, advanced dashboarding, and social impact measurement tools.`;
  }

  return `**Placement Decision Support Overview:**\n\n- **Current Placement Rate:** 94% (47 of 50 students placed in demonstration dataset).\n- **Active Recruiters:** 28 hiring partners across 12 development sectors.\n- **Strategic Focus:** Focus on bridging the Excel (-1.3) and Communication (-1.1) skill gaps to elevate interview-to-offer conversion above 40%.`;
}

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
