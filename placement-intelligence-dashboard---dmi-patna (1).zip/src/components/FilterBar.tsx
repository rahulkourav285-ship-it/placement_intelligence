import React from 'react';
import { Filter, RotateCcw, MapPin } from 'lucide-react';
import { FilterState } from '../types';
import { SECTORS, RECRUITERS, SKILL_CATEGORIES, STATE_REGIONS } from '../data/mockData';

interface FilterBarProps {
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
}

export const FilterBar: React.FC<FilterBarProps> = ({ filters, setFilters }) => {
  const resetFilters = () => {
    setFilters({
      academicYear: 'All',
      batch: 'All',
      sector: 'All',
      recruiter: 'All',
      jobFunction: 'All',
      skillCategory: 'All',
      placementStatus: 'All',
      stateRegion: 'All'
    });
  };

  const hasActiveFilters =
    filters.sector !== 'All' ||
    filters.recruiter !== 'All' ||
    filters.jobFunction !== 'All' ||
    filters.skillCategory !== 'All' ||
    filters.placementStatus !== 'All' ||
    filters.academicYear !== 'All' ||
    filters.batch !== 'All' ||
    filters.stateRegion !== 'All';

  return (
    <div className="bg-white border-b border-gray-200 px-4 py-2 shadow-xs">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center gap-2 sm:gap-3 text-xs">
        
        <div className="flex items-center space-x-1.5 text-[#002B5B] font-bold text-[10px] uppercase tracking-wider pr-2 border-r border-gray-200">
          <Filter className="w-3.5 h-3.5 text-[#002B5B]" />
          <span>Filters:</span>
        </div>

        {/* Sector Filter */}
        <select
          value={filters.sector}
          onChange={(e) => setFilters(prev => ({ ...prev, sector: e.target.value }))}
          className="bg-gray-50 border border-gray-200 rounded px-2.5 py-1 text-[#2D3436] font-medium text-xs focus:ring-1 focus:ring-[#002B5B] focus:outline-none cursor-pointer"
        >
          <option value="All">All Sectors</option>
          {SECTORS.map(s => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>

        {/* Recruiter Filter */}
        <select
          value={filters.recruiter}
          onChange={(e) => setFilters(prev => ({ ...prev, recruiter: e.target.value }))}
          className="bg-gray-50 border border-gray-200 rounded px-2.5 py-1 text-[#2D3436] font-medium text-xs focus:ring-1 focus:ring-[#002B5B] focus:outline-none cursor-pointer"
        >
          <option value="All">All Recruiters</option>
          {RECRUITERS.map(r => (
            <option key={r.recruiter_id} value={r.organisation}>{r.organisation}</option>
          ))}
        </select>

        {/* State / Region Filter */}
        <div className="flex items-center bg-gray-50 border border-gray-200 rounded px-1.5">
          <MapPin className="w-3 h-3 text-[#4C7031] shrink-0" />
          <select
            value={filters.stateRegion}
            onChange={(e) => setFilters(prev => ({ ...prev, stateRegion: e.target.value }))}
            className="bg-transparent py-1 px-1 text-[#2D3436] font-medium text-xs focus:outline-none cursor-pointer"
          >
            <option value="All">All State Regions</option>
            {STATE_REGIONS.filter(r => r !== 'All').map(reg => (
              <option key={reg} value={reg}>{reg}</option>
            ))}
          </select>
        </div>

        {/* Skill Category Filter */}
        <select
          value={filters.skillCategory}
          onChange={(e) => setFilters(prev => ({ ...prev, skillCategory: e.target.value }))}
          className="bg-gray-50 border border-gray-200 rounded px-2.5 py-1 text-[#2D3436] font-medium text-xs focus:ring-1 focus:ring-[#002B5B] focus:outline-none cursor-pointer"
        >
          <option value="All">All Skill Categories</option>
          {SKILL_CATEGORIES.map(cat => (
            <option key={cat} value={cat}>{cat}</option>
          ))}
        </select>

        {/* Placement Status Filter */}
        <select
          value={filters.placementStatus}
          onChange={(e) => setFilters(prev => ({ ...prev, placementStatus: e.target.value }))}
          className="bg-gray-50 border border-gray-200 rounded px-2.5 py-1 text-[#2D3436] font-medium text-xs focus:ring-1 focus:ring-[#002B5B] focus:outline-none cursor-pointer"
        >
          <option value="All">All Statuses</option>
          <option value="Placed">Placed Only</option>
          <option value="In Process">In Process</option>
          <option value="Seeking Offers">Seeking Offers</option>
        </select>

        {/* Reset Filters */}
        {hasActiveFilters && (
          <button
            onClick={resetFilters}
            className="flex items-center space-x-1 text-[#4C7031] hover:text-[#385423] font-bold text-[11px] px-2.5 py-1 bg-[#4C7031]/10 hover:bg-[#4C7031]/20 rounded border border-[#4C7031]/30 transition-colors ml-auto cursor-pointer"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset Filters</span>
          </button>
        )}

      </div>
    </div>
  );
};
