import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';
import { INTERVIEW_REJECTION_DATA, REJECTION_RISK_BY_SKILL } from '../../data/mockData';
import { AlertTriangle, FileCheck2, Zap } from 'lucide-react';

export const InterviewAnalyticsView: React.FC = () => {

  // Cumulative pareto percentage calculation
  let runningTotal = 0;
  const paretoData = INTERVIEW_REJECTION_DATA.map(item => {
    runningTotal += item.percentage;
    return {
      reason: item.reason,
      percentage: item.percentage,
      cumulative: runningTotal,
      stage: item.stage
    };
  });

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="border-b border-slate-200 pb-3">
        <h2 className="text-lg font-bold text-slate-900">Interview Analytics & Rejection Diagnostics</h2>
        <p className="text-xs text-slate-600">
          Stage-by-stage candidate drop-off, rejection root cause analysis and skill risk matrix
        </p>
      </div>

      {/* Bottleneck Callout Banner */}
      <div className="bg-rose-950 text-rose-100 border border-rose-800 rounded-lg p-4 text-xs space-y-1.5 shadow-xs">
        <div className="flex items-center space-x-2 font-bold text-rose-300 text-sm">
          <AlertTriangle className="w-4 h-4 text-rose-400" />
          <span>Most Common Interview Bottleneck (Diagnostic Finding):</span>
        </div>
        <p className="text-slate-200 leading-relaxed">
          Communication skills (32%) and Excel / Analytical Case performance (24%) account for <strong>56% of total candidate rejections</strong> across visiting recruiter drives in the demonstration dataset.
        </p>
      </div>

      {/* Pareto Chart: Reasons for Candidate Rejection */}
      <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs space-y-3">
        <div className="border-b border-slate-100 pb-2">
          <h3 className="text-xs font-bold text-slate-800">Candidate Rejection Drivers (Pareto Frequency Distribution)</h3>
          <p className="text-[11px] text-slate-500">Categorized root causes reported during recruiter interview feedback</p>
        </div>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={paretoData} margin={{ top: 10, right: 30, left: 0, bottom: 25 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
              <XAxis dataKey="reason" tick={{ fontSize: 9, fill: '#334155' }} interval={0} angle={-15} textAnchor="end" />
              <YAxis domain={[0, 40]} tick={{ fontSize: 10, fill: '#475569' }} />
              <Tooltip formatter={(val: any) => [`${val}% of Rejections`, 'Share']} contentStyle={{ backgroundColor: '#0f2942', borderRadius: '4px', color: '#fff', fontSize: '11px' }} />
              <Bar dataKey="percentage" fill="#dc2626" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Rejection Risk by Skill Heatmap Table */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Rejection Risk Heatmap by Skill & Interview Stage</h3>
            <p className="text-[11px] text-slate-500">Mapping candidate weakness impact across recruitment evaluation rounds</p>
          </div>
          <span className="text-[11px] font-mono text-slate-500 bg-white border border-slate-200 px-2 py-0.5 rounded">
            Stage Risk Matrix
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                <th className="p-3">Skill Competency</th>
                <th className="p-3 text-center">Aptitude / Screening</th>
                <th className="p-3 text-center">Case Analysis Round</th>
                <th className="p-3 text-center">Technical Round</th>
                <th className="p-3 text-center">Personal Interview (PI)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-800">
              {REJECTION_RISK_BY_SKILL.map((row, idx) => {
                const getRiskBadge = (text: string) => {
                  if (text.includes('Critical')) return 'bg-rose-100 text-rose-900 border-rose-300 font-bold';
                  if (text.includes('High')) return 'bg-amber-100 text-amber-900 border-amber-300 font-semibold';
                  if (text.includes('Medium')) return 'bg-yellow-50 text-yellow-900 border-yellow-200';
                  return 'bg-slate-100 text-slate-700 border-slate-200';
                };

                return (
                  <tr key={idx} className="hover:bg-slate-50">
                    <td className="p-3 font-semibold text-slate-900">{row.skill}</td>
                    <td className="p-3 text-center"><span className={`px-2.5 py-1 rounded text-[11px] border inline-block ${getRiskBadge(row.aptitude)}`}>{row.aptitude}</span></td>
                    <td className="p-3 text-center"><span className={`px-2.5 py-1 rounded text-[11px] border inline-block ${getRiskBadge(row.case_round)}`}>{row.case_round}</span></td>
                    <td className="p-3 text-center"><span className={`px-2.5 py-1 rounded text-[11px] border inline-block ${getRiskBadge(row.tech_round)}`}>{row.tech_round}</span></td>
                    <td className="p-3 text-center"><span className={`px-2.5 py-1 rounded text-[11px] border inline-block ${getRiskBadge(row.pi_round)}`}>{row.pi_round}</span></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
