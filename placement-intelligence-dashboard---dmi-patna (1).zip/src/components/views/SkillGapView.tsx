import React, { useState } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import { SkillMetric } from '../../types';
import { Target, AlertCircle, ArrowDownRight, Layers } from 'lucide-react';

interface SkillGapViewProps {
  skills: SkillMetric[];
}

export const SkillGapView: React.FC<SkillGapViewProps> = ({ skills }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const filteredSkills = skills.filter(sk => {
    if (selectedCategory !== 'All' && sk.category !== selectedCategory) return false;
    return true;
  });

  // Sort by Priority Skill Index descending
  const sortedSkills = [...filteredSkills].sort((a, b) => b.priority_index - a.priority_index);

  // Data formatted for Grouped Horizontal Bar Chart
  const chartData = sortedSkills.map(sk => ({
    name: sk.skill_name,
    demand: sk.employer_demand,
    proficiency: sk.student_proficiency,
    gap: sk.gap
  }));

  // Categories list
  const categories = ['All', 'Technical', 'Domain & Development', 'Analytics & Tools', 'Soft & Management'];

  return (
    <div className="space-y-6">
      
      {/* Page Header */}
      <div className="border-b border-gray-200 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h2 className="text-lg font-bold text-[#002B5B]">Skill Demand & Gap Analysis</h2>
          <p className="text-xs text-gray-500">
            Employer skill expectations vs average candidate proficiency across Development Management competencies
          </p>
        </div>

        {/* Category Filter Pills */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 rounded text-xs font-bold transition-colors cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-[#002B5B] text-white shadow-xs'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Priority Skill Index Formula Banner */}
      <div className="bg-amber-50 border border-amber-200 rounded p-3.5 text-xs text-amber-900 flex items-start space-x-3">
        <Target className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <div className="font-bold flex items-center space-x-2">
            <span>Priority Skill Index Formula:</span>
            <span className="font-mono bg-amber-100 text-amber-950 px-2 py-0.5 rounded border border-amber-300">
              Priority Index = Skill Gap × Employer Demand
            </span>
          </div>
          <p className="text-[11px] text-amber-800 leading-relaxed">
            Skills with high employer demand and wide student proficiency gaps are mathematically prioritized for immediate academic intervention and bootcamp alignment.
          </p>
        </div>
      </div>

      {/* Grouped Horizontal Bar Chart: Employer Demand vs Student Proficiency */}
      <div className="bg-white p-5 rounded border border-gray-200 shadow-xs space-y-3">
        <div className="border-b border-gray-100 pb-2">
          <h3 className="text-xs font-bold text-[#002B5B]">Employer Demand vs Student Proficiency (1–5 Scale)</h3>
          <p className="text-[11px] text-gray-500">Visual comparison of employer expectations against student readiness</p>
        </div>
        <div className="h-96 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} layout="vertical" margin={{ top: 5, right: 30, left: 100, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
              <XAxis type="number" domain={[0, 5]} tick={{ fontSize: 10, fill: '#475569' }} />
              <YAxis dataKey="name" type="category" tick={{ fontSize: 10, fill: '#334155' }} width={160} />
              <Tooltip formatter={(val: any, name: any) => [`${val} / 5.0`, name === 'demand' ? 'Employer Demand' : 'Student Proficiency']} contentStyle={{ backgroundColor: '#002B5B', borderRadius: '4px', color: '#fff', fontSize: '11px' }} />
              <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
              <Bar dataKey="demand" name="Employer Demand" fill="#002B5B" radius={[0, 4, 4, 0]} />
              <Bar dataKey="proficiency" name="Student Proficiency" fill="#4C7031" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Detailed Skill Priority Index Table */}
      <div className="bg-white rounded border border-gray-200 shadow-xs overflow-hidden">
        <div className="p-4 bg-gray-50 border-b border-gray-200 flex items-center justify-between">
          <div>
            <h3 className="text-xs font-bold text-[#002B5B] uppercase tracking-wider">Ranked Skill Priority Index Table</h3>
            <p className="text-[11px] text-gray-500">Full inventory of competencies ordered by intervention priority</p>
          </div>
          <span className="text-[11px] font-medium text-gray-500">
            Total Competencies Mapped: {sortedSkills.length}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-gray-100 text-[#2D3436] font-bold border-b border-gray-200">
                <th className="p-3">Skill Competency</th>
                <th className="p-3">Category</th>
                <th className="p-3 text-right">Employer Demand (1-5)</th>
                <th className="p-3 text-right">Student Proficiency (1-5)</th>
                <th className="p-3 text-right">Skill Gap</th>
                <th className="p-3 text-right">Priority Index</th>
                <th className="p-3 text-center">Priority Tier</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 text-[#2D3436]">
              {sortedSkills.map((sk, idx) => (
                <tr key={sk.skill_id} className="hover:bg-gray-50 transition-colors">
                  <td className="p-3 font-bold text-[#002B5B] flex items-center space-x-2">
                    <span className="text-[10px] text-gray-400 font-mono">0{idx + 1}.</span>
                    <span>{sk.skill_name}</span>
                  </td>
                  <td className="p-3 font-medium text-gray-600">{sk.category}</td>
                  <td className="p-3 text-right font-bold text-[#002B5B]">{sk.employer_demand.toFixed(1)}</td>
                  <td className="p-3 text-right font-medium text-[#4C7031]">{sk.student_proficiency.toFixed(1)}</td>
                  <td className="p-3 text-right font-bold text-red-600">-{sk.gap.toFixed(1)}</td>
                  <td className="p-3 text-right font-bold font-mono text-[#002B5B]">{sk.priority_index.toFixed(2)}</td>
                  <td className="p-3 text-center">
                    <span className={`inline-block px-2.5 py-0.5 text-[10px] font-bold rounded border ${
                      sk.priority_tier === 'High Priority' ? 'bg-red-50 text-red-800 border-red-200' :
                      sk.priority_tier === 'Medium Priority' ? 'bg-amber-50 text-amber-800 border-amber-200' :
                      'bg-gray-100 text-gray-700 border-gray-200'
                    }`}>
                      {sk.priority_tier}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Heatmap: Skill × Batch Proficiency Matrix */}
      <div className="bg-white p-5 rounded border border-gray-200 shadow-xs space-y-3">
        <div className="border-b border-gray-100 pb-2">
          <h3 className="text-xs font-bold text-[#002B5B]">Skill Proficiency Heatmap across Batches (PDM 10 – PDM 12)</h3>
          <p className="text-[11px] text-gray-500">Color-coded proficiency score evolution across academic cohorts</p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-gray-100 text-[#2D3436] font-bold border-b border-gray-200">
                <th className="p-2.5">Competency</th>
                <th className="p-2.5 text-center">PDM 10 (2023–24)</th>
                <th className="p-2.5 text-center">PDM 11 (2024–25)</th>
                <th className="p-2.5 text-center">PDM 12 (Current)</th>
                <th className="p-2.5 text-center">Trend Indicator</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 text-[#2D3436]">
              {skills.map(sk => {
                const pdm10 = sk.batch_proficiencies['PDM 10'] || 3.0;
                const pdm11 = sk.batch_proficiencies['PDM 11'] || 3.2;
                const pdm12 = sk.batch_proficiencies['PDM 12'] || 3.1;
                const trend = pdm12 >= pdm11 ? '📈 Improving' : '📉 Slight Dip';

                const getBgColor = (val: number) => {
                  if (val >= 4.0) return 'bg-[#4C7031]/20 text-[#4C7031] font-bold border border-[#4C7031]/30';
                  if (val >= 3.4) return 'bg-amber-100 text-amber-900 font-bold border border-amber-200';
                  return 'bg-red-100 text-red-900 font-bold border border-red-200';
                };

                return (
                  <tr key={sk.skill_id} className="hover:bg-gray-50">
                    <td className="p-2.5 font-bold text-[#002B5B]">{sk.skill_name}</td>
                    <td className="p-2.5 text-center"><span className={`px-2.5 py-1 rounded text-xs inline-block ${getBgColor(pdm10)}`}>{pdm10.toFixed(1)}</span></td>
                    <td className="p-2.5 text-center"><span className={`px-2.5 py-1 rounded text-xs inline-block ${getBgColor(pdm11)}`}>{pdm11.toFixed(1)}</span></td>
                    <td className="p-2.5 text-center"><span className={`px-2.5 py-1 rounded text-xs inline-block ${getBgColor(pdm12)}`}>{pdm12.toFixed(1)}</span></td>
                    <td className="p-2.5 text-center font-medium text-gray-600">{trend}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
