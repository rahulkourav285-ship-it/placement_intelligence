import React, { useState } from 'react';
import { Lightbulb, CheckCircle2, Clock, PlayCircle, Layers } from 'lucide-react';

interface RecommendationItem {
  id: string;
  num: string;
  title: string;
  category: string;
  target_impact: string;
  action_plan: string[];
  status: 'Proposed' | 'Approved' | 'In Implementation' | 'Completed';
}

export const RecommendationsView: React.FC = () => {
  const [recs, setRecs] = useState<RecommendationItem[]>([
    {
      id: 'rec_01',
      num: '01',
      title: 'Launch Pre-Placement Technical Bootcamps (Excel, Power BI, M&E)',
      category: 'Skill Gap Remediation',
      target_impact: 'Bridge the -1.3 Excel and -1.1 Power BI employer gaps before recruiter arrival.',
      action_plan: [
        'Mandate 30-hour hands-on Excel & Data Analysis bootcamp for all PDM students in Term 4.',
        'Integrate real social sector datasets (BRLPS, NFHS, District Handbooks) into lab exercises.',
        'Administer pre-and-post evaluation tests to certify candidate readiness.'
      ],
      status: 'In Implementation'
    },
    {
      id: 'rec_02',
      num: '02',
      title: 'Deepen CSR & Digital Development Sector Outreach',
      category: 'Market Outreach',
      target_impact: 'Increase high-CTC offer share (₹9.5+ LPA) by 25% over the next two placement cycles.',
      action_plan: [
        'Formally target corporate CSR foundations in Eastern & Central India.',
        'Position DMI PDM graduates as specialized monitoring and impact evaluation professionals.',
        'Host an annual "Development Management & Impact Round Table" inviting CSR heads.'
      ],
      status: 'Approved'
    },
    {
      id: 'rec_03',
      num: '03',
      title: 'Institutionalize Mock Interview Panels with Senior Alumni',
      category: 'Interview Performance',
      target_impact: 'Increase interview-to-offer conversion rate from 32% to >45%.',
      action_plan: [
        'Pair every student with a senior alumnus (3+ years experience) for 2 rounds of mock interviews.',
        'Focus specifically on Case Study Analysis and Personal Interview articulation.',
        'Provide standardized feedback rubrics to candidates immediately following mock sessions.'
      ],
      status: 'In Implementation'
    },
    {
      id: 'rec_04',
      num: '04',
      title: 'Align PDM Electives with Data Analytics & Digital Development',
      category: 'Curriculum Reform',
      target_impact: 'Sustain curriculum alignment score above 90% across core offerings.',
      action_plan: [
        'Introduce "Big Data & Business Intelligence for Social Impact" as a core elective.',
        'Incorporate GIS and spatial data analysis into rural management coursework.',
        'Review elective syllabi annually with an Industry Advisory Board.'
      ],
      status: 'Proposed'
    },
    {
      id: 'rec_05',
      num: '05',
      title: 'Establish Recruiter Key Account Management (KAM) Protocol',
      category: 'Recruiter Relations',
      target_impact: 'Maintain repeat recruiter rate above 65% and increase partner retention.',
      action_plan: [
        'Assign dedicated faculty/student coordinators to top 15 Strategic Partner organisations.',
        'Conduct post-placement feedback debriefs with HR leads within 30 days of drive completion.',
        'Send quarterly institutional updates and faculty research digests to recruiter leads.'
      ],
      status: 'Approved'
    }
  ]);

  const updateStatus = (id: string, newStatus: any) => {
    setRecs(prev => prev.map(r => r.id === id ? { ...r, status: newStatus } : r));
  };

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="border-b border-slate-200 pb-3">
        <h2 className="text-lg font-bold text-slate-900">Strategic Placement & Academic Recommendations</h2>
        <p className="text-xs text-slate-600">
          Actionable decision-support roadmap derived from diagnostic data analysis for DMI Leadership
        </p>
      </div>

      {/* Recommendation Cards */}
      <div className="space-y-4">
        {recs.map(rec => (
          <div key={rec.id} className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs space-y-3">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-2">
              <div className="flex items-center space-x-3">
                <span className="text-sm font-black text-white bg-[#0f2942] px-2.5 py-1 rounded font-mono">
                  {rec.num}
                </span>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">{rec.title}</h3>
                  <span className="text-[10px] font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded">
                    {rec.category}
                  </span>
                </div>
              </div>

              {/* Status Switcher */}
              <div className="flex items-center space-x-1.5 text-xs">
                <span className="text-slate-500 font-medium text-[11px]">Status:</span>
                <select
                  value={rec.status}
                  onChange={(e) => updateStatus(rec.id, e.target.value)}
                  className={`border rounded px-2.5 py-1 font-bold text-xs cursor-pointer ${
                    rec.status === 'Completed' ? 'bg-emerald-50 text-emerald-800 border-emerald-300' :
                    rec.status === 'In Implementation' ? 'bg-blue-50 text-blue-800 border-blue-300' :
                    rec.status === 'Approved' ? 'bg-amber-50 text-amber-800 border-amber-300' :
                    'bg-slate-100 text-slate-700 border-slate-300'
                  }`}
                >
                  <option value="Proposed">Proposed</option>
                  <option value="Approved">Approved</option>
                  <option value="In Implementation">In Implementation</option>
                  <option value="Completed">Completed</option>
                </select>
              </div>
            </div>

            {/* Target Impact */}
            <div className="bg-slate-50 p-3 rounded border border-slate-200 text-xs">
              <span className="font-bold text-slate-900">Expected Strategic Impact: </span>
              <span className="text-slate-700 font-medium">{rec.target_impact}</span>
            </div>

            {/* Action Items */}
            <div className="space-y-1.5 text-xs">
              <span className="font-bold text-slate-800">Key Implementation Action Items:</span>
              <ul className="list-disc list-inside space-y-1 text-slate-700 text-[11px]">
                {rec.action_plan.map((act, idx) => (
                  <li key={idx} className="leading-relaxed">{act}</li>
                ))}
              </ul>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
};
