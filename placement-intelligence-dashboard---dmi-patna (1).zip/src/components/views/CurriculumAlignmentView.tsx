import React from 'react';
import { CourseAlignment } from '../../types';
import { BookOpen, Award, CheckCircle2, ArrowRight } from 'lucide-react';

interface CurriculumAlignmentViewProps {
  courseAlignments: CourseAlignment[];
}

export const CurriculumAlignmentView: React.FC<CurriculumAlignmentViewProps> = ({
  courseAlignments
}) => {
  return (
    <div className="space-y-6">
      
      {/* Page Title */}
      <div className="border-b border-slate-200 pb-3">
        <h2 className="text-lg font-bold text-slate-900">Curriculum → Skills → Employer Demand Alignment</h2>
        <p className="text-xs text-slate-600">
          Decision support mapping evaluating course offering relevance against market employer requirements
        </p>
      </div>

      {/* Formula Card */}
      <div className="bg-[#0f2942] text-white p-4 rounded-lg border border-slate-800 shadow-xs space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center space-x-1.5">
            <Award className="w-4 h-4" />
            <span>Curriculum Alignment Score Formula</span>
          </span>
          <span className="text-[10px] bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded font-mono">
            Normalized % Scale
          </span>
        </div>
        <div className="text-xs font-mono bg-slate-900/90 p-2.5 rounded border border-slate-800 text-slate-200">
          Alignment Score % = (Employer Skill Demand × Skill Coverage × Student Proficiency) / Max Normalization
        </div>
        <p className="text-[11px] text-slate-300 leading-relaxed">
          Courses scoring above 85% alignment demonstrate direct employer pipeline pull and high post-graduation placement conversion.
        </p>
      </div>

      {/* Course Alignment Table */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-200">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Course Alignment Score Matrix</h3>
          <p className="text-[11px] text-slate-500">Evaluation of DMI PDM electives and core coursework against industry expectations</p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                <th className="p-3">Course / Elective Name</th>
                <th className="p-3">Primary Skills Developed</th>
                <th className="p-3 text-right">Skill Coverage (1-5)</th>
                <th className="p-3 text-right">Employer Demand (1-5)</th>
                <th className="p-3 text-right">Student Proficiency</th>
                <th className="p-3 text-right font-bold text-emerald-800">Alignment Score</th>
                <th className="p-3 text-right">Placement Rate</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-800">
              {courseAlignments.map(course => (
                <tr key={course.course_id} className="hover:bg-slate-50 transition-colors">
                  <td className="p-3 font-semibold text-slate-900">{course.course_name}</td>
                  <td className="p-3">
                    <div className="flex flex-wrap gap-1">
                      {course.skills_covered.map((sk, idx) => (
                        <span key={idx} className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded text-[10px] font-medium border border-slate-200">
                          {sk}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="p-3 text-right font-mono text-slate-700">{course.skill_coverage_score.toFixed(1)}</td>
                  <td className="p-3 text-right font-mono text-blue-900 font-bold">{course.employer_demand_score.toFixed(1)}</td>
                  <td className="p-3 text-right font-mono text-slate-700">{course.student_proficiency_avg.toFixed(1)}</td>
                  <td className="p-3 text-right font-black font-mono text-emerald-800 text-sm">{course.alignment_score}%</td>
                  <td className="p-3 text-right font-bold text-slate-900">{course.placement_rate_pct}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Curriculum Flow Representation */}
      <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs space-y-4">
        <div className="border-b border-slate-100 pb-2">
          <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Academic Flow: Course → Skill → Employer Demand → Outcome</h3>
          <p className="text-[11px] text-slate-500">Structural progression linking classroom learning to final placement</p>
        </div>

        <div className="space-y-3">
          {courseAlignments.map((c, i) => (
            <div key={i} className="p-3 bg-slate-50 rounded border border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
              
              <div className="flex items-center space-x-2 font-bold text-slate-900 md:w-1/4">
                <BookOpen className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>{c.course_name}</span>
              </div>

              <div className="flex items-center space-x-2 text-slate-600 md:w-1/3">
                <ArrowRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span className="font-semibold text-slate-800">Skills:</span>
                <span className="truncate">{c.skills_covered.join(', ')}</span>
              </div>

              <div className="flex items-center space-x-3 md:w-1/3 justify-end text-right">
                <div>
                  <span className="text-[10px] text-slate-500 block">Alignment Score</span>
                  <span className="font-extrabold text-emerald-800">{c.alignment_score}%</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block">Placement Rate</span>
                  <span className="font-extrabold text-slate-900">{c.placement_rate_pct}%</span>
                </div>
              </div>

            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
