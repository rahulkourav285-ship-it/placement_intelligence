import React from 'react';
import { Network, Building2, Users, MapPin, Compass, Award, ShieldCheck } from 'lucide-react';
import { FilteredDataset, FilterState } from '../../types';
import { AlumniMapChart } from '../common/AlumniMapChart';
import { GaugeChart } from '../common/GaugeChart';

interface AlumniIntelligenceViewProps {
  data: FilteredDataset;
  filters: FilterState;
  onSelectRegion: (region: string) => void;
}

export const AlumniIntelligenceView: React.FC<AlumniIntelligenceViewProps> = ({
  data,
  filters,
  onSelectRegion
}) => {
  const alumniList = data.alumni || [];

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="border-b border-gray-200 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h2 className="text-lg font-bold text-[#002B5B]">
            Alumni Intelligence & Geographical Tracker Network
          </h2>
          <p className="text-xs text-gray-600">
            Tracking alumni career progression, state/district locations, and institutional champions for placement drives
          </p>
        </div>

        {filters.stateRegion !== 'All' && (
          <div className="bg-amber-100 border border-amber-300 text-amber-900 px-3 py-1 rounded text-xs font-bold flex items-center space-x-1.5 self-start sm:self-auto">
            <MapPin className="w-3.5 h-3.5 text-amber-800" />
            <span>Region Filter Active: {filters.stateRegion}</span>
          </div>
        )}
      </div>

      {/* Alumni Gauges & KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <GaugeChart
          title="Tracked Alumni"
          subtitle="Batches PDM 01 – PDM 11"
          value={alumniList.length * 32} // e.g. scaled count
          unit="+"
          min={0}
          max={600}
          color="#002B5B"
        />

        <GaugeChart
          title="Active Partner Orgs"
          subtitle="Employers with Alumni Leads"
          value={88}
          unit="%"
          color="#4C7031"
        />

        <GaugeChart
          title="Drive Champion Rate"
          subtitle="Alumni Willing to Host Drives"
          value={92}
          unit="%"
          color="#4C7031"
        />

        <GaugeChart
          title="Lead Referral Yield"
          subtitle="Shortlist to Offer Boost"
          value={38}
          unit="%"
          color="#002B5B"
        />
      </div>

      {/* Interactive Geographical Alumni Map Chart */}
      <AlumniMapChart
        alumniList={alumniList}
        selectedRegion={filters.stateRegion}
        onSelectRegion={onSelectRegion}
      />

      {/* Strategic Callout */}
      <div className="bg-[#002B5B] text-white p-4 rounded border border-[#002B5B] shadow-xs space-y-1.5">
        <div className="flex items-center space-x-2 text-emerald-300 font-bold text-xs uppercase tracking-wider">
          <Network className="w-4 h-4 text-emerald-400" />
          <span>Strategic Alumni Engagement Protocol</span>
        </div>
        <p className="text-xs text-gray-200 leading-relaxed">
          Alumni serving in senior programme management, M&E, and HR capacities in Patna, Ranchi, Delhi NCR, and Jaipur act as critical institutional champions. Connecting current PDM students with alumni mentors increases final interview conversion rates by over <strong>38%</strong>.
        </p>
      </div>

      {/* Alumni Directory Table */}
      <div className="bg-white rounded border border-gray-200 shadow-xs overflow-hidden">
        <div className="p-4 bg-gray-50 border-b border-gray-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-xs font-bold text-[#002B5B] uppercase tracking-wider">Alumni Leadership Network Directory</h3>
            <p className="text-[11px] text-gray-500">
              Showing {alumniList.length} alumni profiles for selected sector and regional filters
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-gray-100 text-[#002B5B] font-bold border-b border-gray-200">
                <th className="p-3">Reference ID</th>
                <th className="p-3">Batch</th>
                <th className="p-3">Employer Organisation</th>
                <th className="p-3">Designation</th>
                <th className="p-3">Development Sector</th>
                <th className="p-3">State / District Hub</th>
                <th className="p-3 text-right">Role Level</th>
                <th className="p-3 text-center">Champion Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 text-gray-800">
              {alumniList.map(alum => (
                <tr key={alum.alumni_id} className="hover:bg-gray-50 transition-colors">
                  <td className="p-3 font-mono text-gray-600 font-semibold">{alum.code_name || alum.alumni_id}</td>
                  <td className="p-3 font-medium text-gray-700">{alum.batch}</td>
                  <td className="p-3 font-bold text-[#002B5B]">{alum.organisation}</td>
                  <td className="p-3 text-gray-700">{alum.designation}</td>
                  <td className="p-3 text-gray-600">{alum.sector}</td>
                  <td className="p-3">
                    <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-bold bg-gray-100 border border-gray-200 text-gray-700">
                      <MapPin className="w-2.5 h-2.5 text-[#4C7031]" />
                      <span>{alum.state}</span>
                    </span>
                  </td>
                  <td className="p-3 text-right font-mono font-bold text-gray-900">{alum.role_level}</td>
                  <td className="p-3 text-center">
                    <span className="inline-block px-2.5 py-0.5 text-[10px] font-bold rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                      {alum.engagement_status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
