import React, { useState } from 'react';
import { Student } from '../../types';
import { Search, UserCheck, AlertTriangle, CheckCircle2, ChevronRight, X, BookOpen, Target } from 'lucide-react';

interface StudentEmployabilityViewProps {
  students: Student[];
}

export const StudentEmployabilityView: React.FC<StudentEmployabilityViewProps> = ({ students }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);

  const filteredStudents = students.filter(st => {
    const matchesSearch = st.student_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          st.batch.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          st.specialization.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || st.placement_status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="border-b border-slate-200 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h2 className="text-lg font-bold text-slate-900">Student Employability & Diagnostic Index</h2>
          <p className="text-xs text-slate-600">
            Individual candidate readiness scores, skill gap identification and targeted remedial intervention plans
          </p>
        </div>

        {/* Search & Status Filter */}
        <div className="flex items-center space-x-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-2 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search Candidate ID (e.g. PDM12-024)..."
              className="pl-8 pr-3 py-1 bg-white border border-slate-300 rounded text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500 w-60"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-white border border-slate-300 rounded px-2.5 py-1 text-xs text-slate-700 font-medium cursor-pointer"
          >
            <option value="All">All Statuses</option>
            <option value="Placed">Placed</option>
            <option value="In Process">In Process</option>
            <option value="Seeking Offers">Seeking Offers</option>
          </select>
        </div>
      </div>

      {/* Summary KPI row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
        <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-xs">
          <span className="text-[10px] text-slate-500 font-bold uppercase">Total Candidate Cohort</span>
          <div className="text-xl font-black text-slate-900">{students.length} Candidates</div>
          <p className="text-[10px] text-slate-500">PDM 12 Batch</p>
        </div>

        <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-xs">
          <span className="text-[10px] text-slate-500 font-bold uppercase">Placed Candidates</span>
          <div className="text-xl font-black text-emerald-700">
            {students.filter(s => s.placement_status === 'Placed').length} ({Math.round((students.filter(s => s.placement_status === 'Placed').length / students.length) * 100)}%)
          </div>
          <p className="text-[10px] text-slate-500">Offers accepted</p>
        </div>

        <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-xs">
          <span className="text-[10px] text-slate-500 font-bold uppercase">Average Employability Index</span>
          <div className="text-xl font-black text-indigo-700">79.4 / 100</div>
          <p className="text-[10px] text-slate-500">Diagnostic average</p>
        </div>

        <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-xs">
          <span className="text-[10px] text-slate-500 font-bold uppercase">Candidates Needing Bootcamp</span>
          <div className="text-xl font-black text-amber-700">8 Candidates</div>
          <p className="text-[10px] text-slate-500">Targeted support</p>
        </div>
      </div>

      {/* Student Employability Directory Table */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Candidate Diagnostic Scorecard Directory</h3>
            <p className="text-[11px] text-slate-500">Comprehensive inventory of student employability scores and placement outcomes</p>
          </div>
          <span className="text-[11px] font-mono text-slate-600">
            Showing {filteredStudents.length} Candidates
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                <th className="p-3">Candidate ID</th>
                <th className="p-3">Batch</th>
                <th className="p-3">Specialization Track</th>
                <th className="p-3 text-right">CGPA</th>
                <th className="p-3 text-right">Employability Score</th>
                <th className="p-3 text-center">Placement Status</th>
                <th className="p-3">Placed Organisation</th>
                <th className="p-3 text-right">CTC (LPA)</th>
                <th className="p-3 text-center">Diagnostic Scorecard</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-800">
              {filteredStudents.map(st => (
                <tr key={st.student_id} className="hover:bg-slate-50 transition-colors">
                  <td className="p-3 font-mono font-bold text-slate-900">{st.student_id}</td>
                  <td className="p-3 font-medium text-slate-600">{st.batch}</td>
                  <td className="p-3 text-slate-700">{st.specialization}</td>
                  <td className="p-3 text-right font-mono font-semibold text-slate-800">{st.cgpa.toFixed(2)}</td>
                  <td className="p-3 text-right font-mono font-black text-indigo-800 text-sm">{st.employability_score}</td>
                  <td className="p-3 text-center">
                    <span className={`inline-block px-2.5 py-0.5 text-[10px] font-bold rounded-full border ${
                      st.placement_status === 'Placed' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' :
                      st.placement_status === 'In Process' ? 'bg-amber-50 text-amber-800 border-amber-200' :
                      'bg-rose-50 text-rose-800 border-rose-200'
                    }`}>
                      {st.placement_status}
                    </span>
                  </td>
                  <td className="p-3 font-semibold text-slate-900">{st.placed_recruiter || '—'}</td>
                  <td className="p-3 text-right font-semibold text-emerald-700">
                    {st.ctc_lpa ? `₹${st.ctc_lpa} LPA` : '—'}
                  </td>
                  <td className="p-3 text-center">
                    <button
                      onClick={() => setSelectedStudent(st)}
                      className="text-indigo-700 hover:text-indigo-800 font-semibold text-[11px] hover:underline cursor-pointer"
                    >
                      View Diagnostics
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Student Diagnostic Modal */}
      {selectedStudent && (
        <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-xl overflow-hidden border border-slate-200">
            
            {/* Header */}
            <div className="bg-[#0f2942] text-white p-4 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                  <UserCheck className="w-4 h-4 text-emerald-400" />
                  <span>Candidate Scorecard: {selectedStudent.student_id}</span>
                </h3>
                <p className="text-xs text-slate-300">Batch {selectedStudent.batch} | Track: {selectedStudent.specialization}</p>
              </div>
              <button
                onClick={() => setSelectedStudent(null)}
                className="p-1 text-slate-300 hover:text-white rounded hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="p-5 space-y-4 text-xs">
              
              <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200 rounded">
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase">Employability Index</span>
                  <div className="text-xl font-black text-indigo-800 font-mono">{selectedStudent.employability_score} / 100</div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-bold text-slate-500 uppercase">Placement Status</span>
                  <div className="text-xs font-bold text-slate-900 bg-emerald-100 text-emerald-900 px-2.5 py-0.5 rounded border border-emerald-300">
                    {selectedStudent.placement_status} {selectedStudent.placed_recruiter ? `(${selectedStudent.placed_recruiter})` : ''}
                  </div>
                </div>
              </div>

              {/* Skill Scores Grid */}
              <div className="space-y-1">
                <span className="font-bold text-slate-800">Skill Competency Ratings (1-5 Scale):</span>
                <div className="grid grid-cols-2 gap-2 pt-1">
                  {Object.entries(selectedStudent.skills).map(([sk, val]) => (
                    <div key={sk} className="flex justify-between p-2 bg-slate-50 rounded border border-slate-200">
                      <span className="font-medium text-slate-700">{sk}</span>
                      <span className="font-bold font-mono text-slate-900">{val} / 5.0</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recommended Interventions */}
              <div className="space-y-1.5 bg-amber-50 p-3 rounded border border-amber-200 text-amber-950">
                <span className="font-bold text-amber-900 flex items-center space-x-1">
                  <Target className="w-3.5 h-3.5 text-amber-700" />
                  <span>Targeted Remedial Interventions:</span>
                </span>
                <ul className="list-disc list-inside space-y-1 text-[11px] font-medium text-amber-900">
                  {selectedStudent.recommended_interventions.map((inv, i) => (
                    <li key={i}>{inv}</li>
                  ))}
                </ul>
              </div>

            </div>

            {/* Footer */}
            <div className="p-3 bg-slate-50 border-t border-slate-200 text-right">
              <button
                onClick={() => setSelectedStudent(null)}
                className="bg-slate-800 hover:bg-slate-900 text-white font-medium px-4 py-1.5 rounded text-xs cursor-pointer"
              >
                Close Scorecard
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
