import React from 'react';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import { SectorTrend } from '../../types';
import { TrendingUp, Compass, CheckCircle2 } from 'lucide-react';

interface SectorTrendsViewProps {
  sectorTrends: SectorTrend[];
}

export const SectorTrendsView: React.FC<SectorTrendsViewProps> = ({ sectorTrends }) => {

  // Sector Growth YoY Chart Data
  const growthData = sectorTrends.map(st => ({
    sector: st.sector,
    demand: st.hiring_demand_count,
    growth: st.yoy_growth_pct,
    avg_ctc: st.avg_ctc_lpa
  }));

  // Historical sector hiring trend lines
  const historicalTrendData = [
    { year: '2023–24', Livelihoods: 12, CSR: 8, Govt: 9, Research: 4, Data: 2 },
    { year: '2024–25', Livelihoods: 15, CSR: 10, Govt: 10, Research: 6, Data: 4 },
    { year: '2025–26', Livelihoods: 18, CSR: 12, Govt: 11, Research: 8, Data: 6 }
  ];

  return (
    <div className="space-y-6">
      
      {/* Page Title */}
      <div className="border-b border-slate-200 pb-3">
        <h2 className="text-lg font-bold text-slate-900">Development Sector Hiring Trends</h2>
        <p className="text-xs text-slate-600">
          Macro sector dynamics, YoY growth trajectories, compensation bands and skill demand mapping
        </p>
      </div>

      {/* Diagnostic Statement Banner */}
      <div className="bg-emerald-950 text-emerald-200 border border-emerald-800 rounded-lg p-4 text-xs space-y-2">
        <div className="flex items-center space-x-2 font-bold text-emerald-400">
          <Compass className="w-4 h-4 text-emerald-400" />
          <span>Sector Attractiveness Diagnostic Finding:</span>
        </div>
        <p className="text-slate-200 leading-relaxed">
          "Which sectors are becoming more attractive for DMI graduates?" <br />
          Data indicates that while <strong className="text-white">Livelihoods</strong> and <strong className="text-white">Government Programmes</strong> remain DMI's highest volume core employers, <strong className="text-white">Data / Digital Development (+30% YoY)</strong>, <strong className="text-white">Research & Consulting (+22% YoY)</strong>, and <strong className="text-white">Climate & Sustainability (+25% YoY)</strong> represent the fastest growing premium compensation channels.
        </p>
      </div>

      {/* Row 1: Sector Growth Trajectory & Hiring Volume */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        
        {/* Sector Hiring Demand & Growth Bar */}
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs space-y-3">
          <div className="border-b border-slate-100 pb-2">
            <h3 className="text-xs font-bold text-slate-800">Hiring Demand & YoY Growth Rate by Sector</h3>
            <p className="text-[11px] text-slate-500">Student intake volume alongside percentage YoY expansion</p>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={growthData} margin={{ top: 10, right: 20, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="sector" tick={{ fontSize: 9, fill: '#334155' }} interval={0} />
                <YAxis domain={[0, 25]} tick={{ fontSize: 10, fill: '#475569' }} />
                <Tooltip formatter={(val: any, name: any) => [name === 'demand' ? `${val} Students Hired` : `+${val}% YoY Growth`, name === 'demand' ? 'Hires' : 'YoY Growth']} contentStyle={{ backgroundColor: '#0f2942', borderRadius: '4px', color: '#fff', fontSize: '11px' }} />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Bar dataKey="demand" name="Total Hires" fill="#15803d" radius={[4, 4, 0, 0]} />
                <Bar dataKey="growth" name="YoY Growth %" fill="#0d9488" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Multi-Line Chart: Sector Trajectory over Academic Years */}
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs space-y-3">
          <div className="border-b border-slate-100 pb-2">
            <h3 className="text-xs font-bold text-slate-800">Multi-Year Sector Hiring Progression (2023–26)</h3>
            <p className="text-[11px] text-slate-500">Cohort hiring expansion across key development verticals</p>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={historicalTrendData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="year" tick={{ fontSize: 10, fill: '#475569' }} />
                <YAxis domain={[0, 20]} tick={{ fontSize: 10, fill: '#475569' }} />
                <Tooltip contentStyle={{ backgroundColor: '#0f2942', borderRadius: '4px', color: '#fff', fontSize: '11px' }} />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Line type="monotone" dataKey="Livelihoods" stroke="#15803d" strokeWidth={2.5} />
                <Line type="monotone" dataKey="CSR" stroke="#1e40af" strokeWidth={2} />
                <Line type="monotone" dataKey="Govt" stroke="#b45309" strokeWidth={2} />
                <Line type="monotone" dataKey="Research" stroke="#6b21a8" strokeWidth={2} />
                <Line type="monotone" dataKey="Data" stroke="#0369a1" strokeWidth={2.5} strokeDasharray="3 3" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

      {/* Sector Directory Table & Key Skills Demand */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-200">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Sector Intelligence & Skill Demand Profile</h3>
          <p className="text-[11px] text-slate-500">Compensation, repeat rate, roles and employer skill expectations by sector</p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                <th className="p-3">Development Sector</th>
                <th className="p-3 text-right">2025–26 Hires</th>
                <th className="p-3 text-right">YoY Growth</th>
                <th className="p-3 text-right">Avg CTC (LPA)</th>
                <th className="p-3 text-right">Repeat Hiring %</th>
                <th className="p-3">Top Roles Offered</th>
                <th className="p-3">Primary Skills Demanded</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-800">
              {sectorTrends.map((st, idx) => (
                <tr key={idx} className="hover:bg-slate-50 transition-colors">
                  <td className="p-3 font-semibold text-slate-900">{st.sector}</td>
                  <td className="p-3 text-right font-bold text-slate-900">{st.hiring_demand_count}</td>
                  <td className="p-3 text-right font-bold text-emerald-700">+{st.yoy_growth_pct}%</td>
                  <td className="p-3 text-right font-semibold text-slate-800">₹{st.avg_ctc_lpa} LPA</td>
                  <td className="p-3 text-right font-mono text-slate-600">{st.repeat_hiring_rate}%</td>
                  <td className="p-3 text-slate-700 text-[11px]">
                    {st.top_roles.slice(0, 2).join(', ')}
                  </td>
                  <td className="p-3">
                    <div className="flex flex-wrap gap-1">
                      {st.key_skills.map((sk, sidx) => (
                        <span key={sidx} className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded text-[10px] font-medium border border-slate-200">
                          {sk}
                        </span>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
