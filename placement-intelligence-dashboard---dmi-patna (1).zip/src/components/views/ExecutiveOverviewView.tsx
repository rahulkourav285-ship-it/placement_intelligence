import React from 'react';
import {
  TrendingUp,
  Users,
  Building2,
  UserPlus,
  IndianRupee,
  Repeat,
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
  ArrowUpRight,
  Target,
  FileText
} from 'lucide-react';
import { ExecutiveSummary } from '../../types';
import { GaugeChart } from '../common/GaugeChart';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

interface ExecutiveOverviewViewProps {
  summary: ExecutiveSummary;
  onNavigateTab: (tab: any) => void;
}

export const ExecutiveOverviewView: React.FC<ExecutiveOverviewViewProps> = ({
  summary,
  onNavigateTab
}) => {
  const { kpis, diagnostics, what_is_working, what_needs_attention, what_to_do_next } = summary;

  // Sector distribution preview chart
  const sectorData = [
    { name: 'Livelihoods', hires: 18, color: '#15803d' },
    { name: 'CSR', hires: 12, color: '#1e40af' },
    { name: 'Govt Programmes', hires: 11, color: '#b45309' },
    { name: 'Agri & Rural', hires: 10, color: '#047857' },
    { name: 'Research & Consult', hires: 8, color: '#6b21a8' },
    { name: 'Data / Digital', hires: 6, color: '#0369a1' }
  ];

  // Top skill gap preview chart
  const skillGapData = [
    { skill: 'Excel', gap: 1.3 },
    { skill: 'Case Analysis', gap: 1.2 },
    { skill: 'Communication', gap: 1.1 },
    { skill: 'Data Analysis', gap: 1.1 },
    { skill: 'Power BI', gap: 1.1 },
    { skill: 'SQL', gap: 1.1 }
  ];

  return (
    <div className="space-y-6">
      
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-gray-200 pb-3">
        <div>
          <h2 className="text-lg font-bold text-[#002B5B] tracking-tight">
            Placement Intelligence — Executive Overview
          </h2>
          <p className="text-xs text-gray-500">
            A decision-support view of placement outcomes, employer demand and student employability
          </p>
        </div>
        <div className="flex items-center space-x-2 text-[11px] text-gray-500">
          <span className="inline-block w-2 h-2 rounded-full bg-[#4C7031]"></span>
          <span>Batch: <strong className="text-[#002B5B]">PDM 12 (2025–26)</strong></span>
        </div>
      </div>

      {/* KPI Cards (8 Cards Grid) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        
        {/* Placement Rate */}
        <div className="bg-white p-4 rounded border border-gray-200 shadow-xs hover:border-[#002B5B]/30 transition-colors">
          <div className="flex items-center justify-between text-gray-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Placement Rate</span>
            <TrendingUp className="w-4 h-4 text-[#4C7031]" />
          </div>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-2xl font-bold text-[#002B5B]">{kpis.placement_rate}%</span>
            <span className="text-[10px] font-bold text-[#4C7031]">
              +{kpis.placement_rate_yoy} pp YoY
            </span>
          </div>
          <p className="text-[9px] text-gray-400 mt-1">Current batch status</p>
        </div>

        {/* Students Placed */}
        <div className="bg-white p-4 rounded border border-gray-200 shadow-xs hover:border-[#002B5B]/30 transition-colors">
          <div className="flex items-center justify-between text-gray-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Students Placed</span>
            <Users className="w-4 h-4 text-[#002B5B]" />
          </div>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-2xl font-bold text-[#002B5B]">{kpis.students_placed}</span>
            <span className="text-[10px] font-medium text-gray-500">of {kpis.students_total} Total</span>
          </div>
          <p className="text-[9px] text-gray-400 mt-1">Eligible candidates</p>
        </div>

        {/* Active Recruiters */}
        <div className="bg-white p-4 rounded border border-gray-200 shadow-xs hover:border-[#002B5B]/30 transition-colors">
          <div className="flex items-center justify-between text-gray-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Active Recruiters</span>
            <Building2 className="w-4 h-4 text-[#002B5B]" />
          </div>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-2xl font-bold text-[#002B5B]">{kpis.active_recruiters}</span>
            <span className="text-[10px] font-bold text-blue-600">{kpis.new_recruiters} New</span>
          </div>
          <p className="text-[9px] text-gray-400 mt-1">Participating orgs</p>
        </div>

        {/* Average CTC */}
        <div className="bg-white p-4 rounded border border-gray-200 shadow-xs hover:border-[#002B5B]/30 transition-colors">
          <div className="flex items-center justify-between text-gray-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Average CTC</span>
            <IndianRupee className="w-4 h-4 text-[#4C7031]" />
          </div>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-2xl font-bold text-[#002B5B]">₹{kpis.avg_ctc_lpa} <span className="text-xs font-normal text-gray-500">LPA</span></span>
            <span className="text-[10px] text-gray-400">Median ₹{kpis.median_ctc_lpa}</span>
          </div>
          <p className="text-[9px] text-gray-400 mt-1">Annual compensation</p>
        </div>

        {/* Repeat Recruiter Rate */}
        <div className="bg-white p-4 rounded border border-gray-200 shadow-xs hover:border-[#002B5B]/30 transition-colors">
          <div className="flex items-center justify-between text-gray-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Repeat Rate</span>
            <Repeat className="w-4 h-4 text-[#002B5B]" />
          </div>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-2xl font-bold text-[#002B5B]">{kpis.repeat_recruiter_rate}%</span>
            <span className="text-[10px] font-bold text-[#4C7031]">High Loyalty</span>
          </div>
          <p className="text-[9px] text-gray-400 mt-1">Recurring drives</p>
        </div>

        {/* Interview Conversion */}
        <div className="bg-white p-4 rounded border border-gray-200 shadow-xs hover:border-[#002B5B]/30 transition-colors">
          <div className="flex items-center justify-between text-gray-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Interview Conversion</span>
            <Target className="w-4 h-4 text-[#002B5B]" />
          </div>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-2xl font-bold text-[#002B5B]">{kpis.interview_conversion}%</span>
            <span className="text-[10px] text-gray-400">Final rounds</span>
          </div>
          <p className="text-[9px] text-gray-400 mt-1">Offers to shortlist ratio</p>
        </div>

        {/* New Recruiter Growth */}
        <div className="bg-white p-4 rounded border border-gray-200 shadow-xs hover:border-[#002B5B]/30 transition-colors">
          <div className="flex items-center justify-between text-gray-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">New Prospect Orgs</span>
            <UserPlus className="w-4 h-4 text-[#4C7031]" />
          </div>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-2xl font-bold text-[#002B5B]">{kpis.new_recruiters}</span>
            <span className="text-[10px] font-bold text-[#4C7031]">Expanded</span>
          </div>
          <p className="text-[9px] text-gray-400 mt-1">First-time partners</p>
        </div>

        {/* Critical Skill Gaps */}
        <div className="bg-white p-4 rounded border border-gray-200 shadow-xs hover:border-[#002B5B]/30 transition-colors">
          <div className="flex items-center justify-between text-gray-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Critical Skill Gaps</span>
            <AlertTriangle className="w-4 h-4 text-amber-500" />
          </div>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-2xl font-bold text-amber-600">{kpis.critical_skill_gaps}</span>
            <span className="text-[10px] font-bold text-amber-600">Priority Action</span>
          </div>
          <p className="text-[9px] text-gray-400 mt-1">Gap ≥ 1.0 points</p>
        </div>

      </div>

      {/* Visual Percentage Gauges Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <GaugeChart
          title="Placement Rate"
          subtitle="Overall Batch Achievement"
          value={kpis.placement_rate}
          unit="%"
          color="#4C7031"
        />
        <GaugeChart
          title="Interview Conversion"
          subtitle="Final Shortlist to Offer Yield"
          value={kpis.interview_conversion}
          unit="%"
          color="#002B5B"
        />
        <GaugeChart
          title="Repeat Partner Rate"
          subtitle="Partner Recruiter Loyalty"
          value={kpis.repeat_recruiter_rate}
          unit="%"
          color="#4C7031"
        />
        <GaugeChart
          title="MIS Readiness"
          subtitle="Validated Student Records"
          value={87}
          unit="%"
          color="#002B5B"
        />
      </div>

      {/* Placement Intelligence at a Glance */}
      <div className="bg-[#002B5B] text-white p-5 rounded border border-[#002B5B] shadow-sm">
        <div className="flex items-center justify-between pb-3 border-b border-white/20 mb-4">
          <h3 className="text-sm font-bold tracking-wide uppercase text-white flex items-center space-x-2">
            <FileText className="w-4 h-4 text-[#4C7031]" />
            <span>Placement Intelligence at a Glance</span>
          </h3>
          <span className="text-[10px] bg-white/10 text-white border border-white/20 px-2 py-0.5 rounded font-mono">
            Executive Briefing
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          
          {/* What is working */}
          <div className="bg-white/10 p-3.5 rounded border border-white/10 space-y-2">
            <div className="flex items-center space-x-2 text-emerald-300 font-bold">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>What is working?</span>
            </div>
            <ul className="space-y-1.5 text-white/90 list-disc list-inside text-[11px]">
              {what_is_working.map((item, idx) => (
                <li key={idx} className="leading-relaxed">{item}</li>
              ))}
            </ul>
          </div>

          {/* What needs attention */}
          <div className="bg-white/10 p-3.5 rounded border border-white/10 space-y-2">
            <div className="flex items-center space-x-2 text-amber-300 font-bold">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>What needs attention?</span>
            </div>
            <ul className="space-y-1.5 text-white/90 list-disc list-inside text-[11px]">
              {what_needs_attention.map((item, idx) => (
                <li key={idx} className="leading-relaxed">{item}</li>
              ))}
            </ul>
          </div>

          {/* What should DMI do next */}
          <div className="bg-white/10 p-3.5 rounded border border-white/10 space-y-2">
            <div className="flex items-center space-x-2 text-sky-300 font-bold">
              <Lightbulb className="w-4 h-4 shrink-0" />
              <span>What should DMI do next?</span>
            </div>
            <ul className="space-y-1.5 text-white/90 list-disc list-inside text-[11px]">
              {what_to_do_next.map((item, idx) => (
                <li key={idx} className="leading-relaxed">{item}</li>
              ))}
            </ul>
          </div>

        </div>
      </div>

      {/* Executive Diagnostic Section */}
      <div className="bg-white p-5 rounded border border-gray-200 shadow-xs space-y-4">
        <div className="border-b border-gray-200 pb-2">
          <h3 className="text-sm font-bold text-[#002B5B]">
            What is driving placement performance?
          </h3>
          <p className="text-xs text-gray-500">
            Root cause diagnostic decomposition across institutional capabilities and candidate readiness
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          
          {/* Strengths Card */}
          <div className="p-4 rounded bg-[#4C7031]/10 border border-[#4C7031]/30 space-y-2">
            <h4 className="font-bold text-[#4C7031] flex items-center space-x-1.5">
              <CheckCircle2 className="w-4 h-4 text-[#4C7031]" />
              <span>Institutional Strengths</span>
            </h4>
            <ul className="space-y-2 text-[#2D3436] font-medium list-disc list-inside text-[11px]">
              {diagnostics.strengths.map((st, i) => (
                <li key={i}>{st}</li>
              ))}
            </ul>
          </div>

          {/* Watch Areas Card */}
          <div className="p-4 rounded bg-amber-50 border border-amber-200 space-y-2">
            <h4 className="font-bold text-amber-900 flex items-center space-x-1.5">
              <AlertTriangle className="w-4 h-4 text-amber-700" />
              <span>Watch Areas & Bottlenecks</span>
            </h4>
            <ul className="space-y-2 text-amber-950 font-medium list-disc list-inside text-[11px]">
              {diagnostics.watch_areas.map((wa, i) => (
                <li key={i}>{wa}</li>
              ))}
            </ul>
          </div>

          {/* Strategic Priorities Card */}
          <div className="p-4 rounded bg-[#002B5B]/10 border border-[#002B5B]/30 space-y-2">
            <h4 className="font-bold text-[#002B5B] flex items-center space-x-1.5">
              <Lightbulb className="w-4 h-4 text-[#002B5B]" />
              <span>Strategic Interventions</span>
            </h4>
            <ul className="space-y-2 text-[#2D3436] font-medium list-disc list-inside text-[11px]">
              {diagnostics.strategic_priorities.map((sp, i) => (
                <li key={i}>{sp}</li>
              ))}
            </ul>
          </div>

        </div>
      </div>

      {/* Visual Previews: Sector Distribution & Skill Gap Priority */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        
        {/* Sector Hiring Distribution Chart */}
        <div className="bg-white p-5 rounded border border-gray-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-gray-100">
            <div>
              <h4 className="text-xs font-bold text-[#002B5B]">Hiring Volume by Sector</h4>
              <p className="text-[11px] text-gray-500">Distribution across primary development domains</p>
            </div>
            <button
              onClick={() => onNavigateTab('sector_trends')}
              className="text-[#4C7031] hover:text-[#385423] text-[11px] font-bold flex items-center space-x-0.5 cursor-pointer"
            >
              <span>View Sectors</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="h-52 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={sectorData} layout="vertical" margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
                <XAxis type="number" textAnchor="end" tick={{ fontSize: 10, fill: '#64748b' }} />
                <YAxis dataKey="name" type="category" tick={{ fontSize: 10, fill: '#334155' }} width={100} />
                <Tooltip
                  formatter={(val: any) => [`${val} Students Placed`, 'Volume']}
                  contentStyle={{ backgroundColor: '#002B5B', borderRadius: '4px', color: '#fff', fontSize: '11px' }}
                />
                <Bar dataKey="hires" fill="#002B5B" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Top Skill Gaps Chart */}
        <div className="bg-white p-5 rounded border border-gray-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-gray-100">
            <div>
              <h4 className="text-xs font-bold text-[#002B5B]">Largest Employer Skill Gaps</h4>
              <p className="text-[11px] text-gray-500">Employer Demand vs Student Proficiency (1-5 scale)</p>
            </div>
            <button
              onClick={() => onNavigateTab('skill_gap')}
              className="text-[#4C7031] hover:text-[#385423] text-[11px] font-bold flex items-center space-x-0.5 cursor-pointer"
            >
              <span>Deep Dive Gaps</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="h-52 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={skillGapData} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="skill" tick={{ fontSize: 10, fill: '#334155' }} />
                <YAxis domain={[0, 2]} tick={{ fontSize: 10, fill: '#64748b' }} />
                <Tooltip
                  formatter={(val: any) => [`-${val} Points Gap`, 'Skill Gap']}
                  contentStyle={{ backgroundColor: '#002B5B', borderRadius: '4px', color: '#fff', fontSize: '11px' }}
                />
                <Bar dataKey="gap" fill="#4C7031" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

    </div>
  );
};
