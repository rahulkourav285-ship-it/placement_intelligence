import React from 'react';
import { ShieldCheck, Database, AlertCircle, FileText, Lock, RefreshCw } from 'lucide-react';

export const DataQualityView: React.FC = () => {
  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="border-b border-slate-200 pb-3">
        <h2 className="text-lg font-bold text-slate-900">Data Quality, Integrity & Methodology Governance</h2>
        <p className="text-xs text-slate-600">
          Transparency guidelines, data completeness metrics, privacy protocols and analytical formulas
        </p>
      </div>

      {/* Quality Overview KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 font-medium">
            <span>Data Completeness Score</span>
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-slate-900">87 %</div>
          <p className="text-[10px] text-emerald-700 font-semibold">High Institutional Integrity Standard</p>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 font-medium">
            <span>Alumni Coverage Ratio</span>
            <Database className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-black text-slate-900">82 %</div>
          <p className="text-[10px] text-slate-500">Tracked across batches PDM 1–11</p>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 font-medium">
            <span>Data Anonymization Level</span>
            <Lock className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-2xl font-black text-emerald-800">100 % PII Protected</div>
          <p className="text-[10px] text-slate-500">Compliant with institutional privacy</p>
        </div>
      </div>

      {/* Important Data Status Disclaimer Card */}
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 text-xs text-amber-950 space-y-2">
        <div className="font-bold text-amber-900 flex items-center space-x-2">
          <AlertCircle className="w-4 h-4 text-amber-700" />
          <span>Institutional Demonstration Dataset Status</span>
        </div>
        <p className="leading-relaxed text-[11px] text-amber-900">
          This website utilizes an illustrative, high-fidelity demonstration dataset structured specifically for Placement Cell diagnostic analysis at Development Management Institute (DMI), Patna. While designed to reflect realistic development-sector hiring dynamics (including JEEViKA, AKRSP, TechnoServe, CARE India, BRLPS, etc.), individual metrics should be evaluated as decision-support prototypes rather than official audited figures.
        </p>
      </div>

      {/* Issue Log & Known Limitations */}
      <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs space-y-3">
        <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider border-b border-slate-100 pb-2">
          Data Quality & Limitation Log
        </h3>
        
        <div className="space-y-2 text-xs">
          <div className="p-3 bg-slate-50 rounded border border-slate-200 flex items-start space-x-3">
            <span className="font-bold text-slate-800 shrink-0">Issue #01:</span>
            <p className="text-slate-700">
              <strong>Partial Interview Feedback:</strong> Qualitatively detailed feedback was captured for 82% of interviewing candidates; remaining candidate feedback was generalized from recruiter summary letters.
            </p>
          </div>

          <div className="p-3 bg-slate-50 rounded border border-slate-200 flex items-start space-x-3">
            <span className="font-bold text-slate-800 shrink-0">Issue #02:</span>
            <p className="text-slate-700">
              <strong>CTC Normalization:</strong> Salary CTC packages for historical batches (PDM 10 & 11) were adjusted for 5% annual CPI inflation to enable apples-to-apples multi-year benchmarking.
            </p>
          </div>

          <div className="p-3 bg-slate-50 rounded border border-slate-200 flex items-start space-x-3">
            <span className="font-bold text-slate-800 shrink-0">Issue #03:</span>
            <p className="text-slate-700">
              <strong>Recruiter Score Normalization:</strong> Scores are computed dynamically based on the current active filter state and updated on a nightly batch schedule.
            </p>
          </div>
        </div>
      </div>

      {/* Analytical Methodology Reference */}
      <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs space-y-3 text-xs">
        <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider border-b border-slate-100 pb-2">
          Analytical Formulas & Methodology Summary
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-3 bg-slate-50 rounded border border-slate-200 space-y-1">
            <span className="font-bold text-slate-900">Skill Gap Index</span>
            <p className="text-slate-600 text-[11px]">
              Calculated as: <code>Employer Demand Score (1-5) - Student Average Proficiency (1-5)</code>. Gaps greater than 1.0 are categorized as critical intervention areas.
            </p>
          </div>

          <div className="p-3 bg-slate-50 rounded border border-slate-200 space-y-1">
            <span className="font-bold text-slate-900">Recruiter Relationship Score</span>
            <p className="text-slate-600 text-[11px]">
              Weighted index combining repeat hiring consistency (25%), hiring volume (25%), internship engagement (20%), alumni presence (15%), and recent drive activity (15%).
            </p>
          </div>
        </div>
      </div>

    </div>
  );
};
