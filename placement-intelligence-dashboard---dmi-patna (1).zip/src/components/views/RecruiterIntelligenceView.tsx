import React, { useState } from 'react';
import { Recruiter } from '../../types';
import {
  Building2,
  Search,
  ChevronRight,
  X,
  Award,
  Users,
  Briefcase,
  IndianRupee,
  Layers
} from 'lucide-react';

interface RecruiterIntelligenceViewProps {
  recruiters: Recruiter[];
}

export const RecruiterIntelligenceView: React.FC<RecruiterIntelligenceViewProps> = ({
  recruiters
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedQuadrant, setSelectedQuadrant] = useState<string>('All');
  const [selectedRecruiter, setSelectedRecruiter] = useState<Recruiter | null>(null);

  const filteredRecruiters = recruiters.filter(r => {
    const matchesSearch = r.organisation.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          r.sector.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesQuadrant = selectedQuadrant === 'All' || r.matrix_quadrant === selectedQuadrant;
    return matchesSearch && matchesQuadrant;
  });

  // Group recruiters into 2x2 Matrix Quadrants
  const strategicPartners = recruiters.filter(r => r.matrix_quadrant === 'Strategic Partners');
  const growthOpportunities = recruiters.filter(r => r.matrix_quadrant === 'Growth Opportunities');
  const maintainQuadrant = recruiters.filter(r => r.matrix_quadrant === 'Maintain');
  const reengageQuadrant = recruiters.filter(r => r.matrix_quadrant === 'Re-engage');

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="border-b border-slate-200 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h2 className="text-lg font-bold text-slate-900">Recruiter Intelligence & Engagement Matrix</h2>
          <p className="text-xs text-slate-600">
            Strategic classification and relationship scoring for Development Management hiring partners
          </p>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search recruiter or sector..."
            className="pl-8 pr-3 py-1 bg-white border border-slate-300 rounded text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500 w-56"
          />
        </div>
      </div>

      {/* Recruiter Relationship Score Formula Card */}
      <div className="bg-[#0f2942] text-white p-4 rounded-lg border border-slate-800 shadow-sm space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center space-x-1.5">
            <Award className="w-4 h-4" />
            <span>Recruiter Relationship Score Methodology</span>
          </span>
          <span className="text-[10px] bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded font-mono">
            Normalized to 100
          </span>
        </div>
        <div className="text-xs font-mono bg-slate-900/90 p-2.5 rounded border border-slate-800 text-slate-200 overflow-x-auto">
          Relationship Score = (Repeat Hiring × 0.25) + (Hiring Volume × 0.25) + (Internship Engagement × 0.20) + (Alumni Presence × 0.15) + (Recent Activity × 0.15)
        </div>
        <p className="text-[11px] text-slate-300 leading-relaxed">
          This quantitative index separates high-value strategic institutional partners from opportunistic recruiters to drive targeted Placement Cell relationship management.
        </p>
      </div>

      {/* Section 11: 2x2 Strategic Recruiter Matrix */}
      <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs space-y-4">
        <div className="border-b border-slate-100 pb-2 flex items-center justify-between">
          <div>
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Recruiter 2×2 Strategic Matrix</h3>
            <p className="text-[11px] text-slate-500">X-Axis: Relationship Strength | Y-Axis: Hiring Potential</p>
          </div>
          <div className="flex space-x-1 text-[11px]">
            {['All', 'Strategic Partners', 'Growth Opportunities', 'Maintain', 'Re-engage'].map(q => (
              <button
                key={q}
                onClick={() => setSelectedQuadrant(q)}
                className={`px-2 py-0.5 rounded cursor-pointer font-medium transition-colors ${
                  selectedQuadrant === q ? 'bg-slate-800 text-white font-semibold' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* 2x2 Grid Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 font-sans">
          
          {/* Top-Right: Strategic Partners (High Relationship + High Potential) */}
          <div className="bg-emerald-50/70 border-2 border-emerald-300 rounded-lg p-3.5 space-y-2">
            <div className="flex items-center justify-between border-b border-emerald-200 pb-1.5">
              <span className="font-bold text-xs text-emerald-900 flex items-center space-x-1">
                <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
                <span>STRATEGIC PARTNERS</span>
              </span>
              <span className="text-[10px] bg-emerald-200 text-emerald-950 font-bold px-2 py-0.5 rounded-full">
                High Strength / High Potential ({strategicPartners.length})
              </span>
            </div>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {strategicPartners.map(r => (
                <button
                  key={r.recruiter_id}
                  onClick={() => setSelectedRecruiter(r)}
                  className="bg-white hover:bg-emerald-100 border border-emerald-300 px-2.5 py-1 rounded text-slate-800 text-xs font-semibold shadow-2xs transition-colors flex items-center space-x-1 cursor-pointer"
                >
                  <span>{r.organisation}</span>
                  <span className="text-[10px] text-emerald-700 font-bold font-mono">({r.relationship_score})</span>
                </button>
              ))}
            </div>
          </div>

          {/* Top-Left: Growth Opportunities (Low Relationship + High Potential) */}
          <div className="bg-blue-50/70 border-2 border-blue-300 rounded-lg p-3.5 space-y-2">
            <div className="flex items-center justify-between border-b border-blue-200 pb-1.5">
              <span className="font-bold text-xs text-blue-900 flex items-center space-x-1">
                <span className="w-2 h-2 rounded-full bg-blue-600"></span>
                <span>GROWTH OPPORTUNITIES</span>
              </span>
              <span className="text-[10px] bg-blue-200 text-blue-950 font-bold px-2 py-0.5 rounded-full">
                Low Strength / High Potential ({growthOpportunities.length})
              </span>
            </div>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {growthOpportunities.map(r => (
                <button
                  key={r.recruiter_id}
                  onClick={() => setSelectedRecruiter(r)}
                  className="bg-white hover:bg-blue-100 border border-blue-300 px-2.5 py-1 rounded text-slate-800 text-xs font-semibold shadow-2xs transition-colors flex items-center space-x-1 cursor-pointer"
                >
                  <span>{r.organisation}</span>
                  <span className="text-[10px] text-blue-700 font-bold font-mono">({r.relationship_score})</span>
                </button>
              ))}
            </div>
          </div>

          {/* Bottom-Right: Maintain (High Relationship + Lower Future Potential) */}
          <div className="bg-amber-50/70 border-2 border-amber-300 rounded-lg p-3.5 space-y-2">
            <div className="flex items-center justify-between border-b border-amber-200 pb-1.5">
              <span className="font-bold text-xs text-amber-900 flex items-center space-x-1">
                <span className="w-2 h-2 rounded-full bg-amber-600"></span>
                <span>MAINTAIN RELATIONSHIP</span>
              </span>
              <span className="text-[10px] bg-amber-200 text-amber-950 font-bold px-2 py-0.5 rounded-full">
                High Strength / Lower Potential ({maintainQuadrant.length})
              </span>
            </div>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {maintainQuadrant.map(r => (
                <button
                  key={r.recruiter_id}
                  onClick={() => setSelectedRecruiter(r)}
                  className="bg-white hover:bg-amber-100 border border-amber-300 px-2.5 py-1 rounded text-slate-800 text-xs font-semibold shadow-2xs transition-colors flex items-center space-x-1 cursor-pointer"
                >
                  <span>{r.organisation}</span>
                  <span className="text-[10px] text-amber-700 font-bold font-mono">({r.relationship_score})</span>
                </button>
              ))}
            </div>
          </div>

          {/* Bottom-Left: Re-engage (Low Relationship + Low Potential) */}
          <div className="bg-slate-100 border-2 border-slate-300 rounded-lg p-3.5 space-y-2">
            <div className="flex items-center justify-between border-b border-slate-200 pb-1.5">
              <span className="font-bold text-xs text-slate-800 flex items-center space-x-1">
                <span className="w-2 h-2 rounded-full bg-slate-500"></span>
                <span>RE-ENGAGE / RE-EVALUATE</span>
              </span>
              <span className="text-[10px] bg-slate-200 text-slate-800 font-bold px-2 py-0.5 rounded-full">
                Low Strength / Low Potential ({reengageQuadrant.length})
              </span>
            </div>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {reengageQuadrant.map(r => (
                <button
                  key={r.recruiter_id}
                  onClick={() => setSelectedRecruiter(r)}
                  className="bg-white hover:bg-slate-200 border border-slate-300 px-2.5 py-1 rounded text-slate-800 text-xs font-semibold shadow-2xs transition-colors flex items-center space-x-1 cursor-pointer"
                >
                  <span>{r.organisation}</span>
                  <span className="text-[10px] text-slate-600 font-bold font-mono">({r.relationship_score})</span>
                </button>
              ))}
            </div>
          </div>

        </div>
      </div>

      {/* Recruiter Level Table */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Recruiter Strategic Directory</h3>
            <p className="text-[11px] text-slate-500">Detailed metric breakdown for development-sector hiring partners</p>
          </div>
          <span className="text-[11px] font-mono text-slate-600">
            Showing {filteredRecruiters.length} Organisations
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                <th className="p-3">Organisation</th>
                <th className="p-3">Development Sector</th>
                <th className="p-3 text-right">Engagement Years</th>
                <th className="p-3 text-right">Total Hired</th>
                <th className="p-3 text-right">Avg CTC (LPA)</th>
                <th className="p-3 text-right">Conversion %</th>
                <th className="p-3 text-right font-bold text-emerald-800">Rel. Score</th>
                <th className="p-3 text-center">Category</th>
                <th className="p-3 text-center">Profile</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-800">
              {filteredRecruiters.map(r => (
                <tr key={r.recruiter_id} className="hover:bg-slate-50 transition-colors">
                  <td className="p-3 font-semibold text-slate-900">{r.organisation}</td>
                  <td className="p-3 font-medium text-slate-600">{r.sector}</td>
                  <td className="p-3 text-right font-mono text-slate-600">{r.relationship_years} yrs</td>
                  <td className="p-3 text-right font-bold text-slate-900">{r.students_hired}</td>
                  <td className="p-3 text-right font-semibold text-emerald-700">₹{r.avg_ctc_lpa}</td>
                  <td className="p-3 text-right font-mono text-slate-700">{r.interview_conversion}%</td>
                  <td className="p-3 text-right font-extrabold font-mono text-emerald-800 text-sm">{r.relationship_score}</td>
                  <td className="p-3 text-center">
                    <span className="inline-block px-2 py-0.5 text-[10px] font-bold rounded-full bg-slate-100 text-slate-800 border border-slate-200">
                      {r.tier_category}
                    </span>
                  </td>
                  <td className="p-3 text-center">
                    <button
                      onClick={() => setSelectedRecruiter(r)}
                      className="text-emerald-700 hover:text-emerald-800 font-semibold text-[11px] hover:underline cursor-pointer"
                    >
                      View Profile
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recruiter Profile Modal Drilldown */}
      {selectedRecruiter && (
        <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-xl overflow-hidden border border-slate-200">
            
            {/* Modal Header */}
            <div className="bg-[#0f2942] text-white p-4 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                  <Building2 className="w-4 h-4 text-emerald-400" />
                  <span>{selectedRecruiter.organisation}</span>
                </h3>
                <p className="text-xs text-slate-300">{selectedRecruiter.sector} Sector Partner</p>
              </div>
              <button
                onClick={() => setSelectedRecruiter(null)}
                className="p-1 text-slate-300 hover:text-white rounded hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 space-y-4 text-xs">
              
              {/* Score Header */}
              <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200 rounded">
                <div>
                  <span className="text-[10px] font-bold uppercase text-slate-500">Relationship Score</span>
                  <div className="text-xl font-black text-emerald-800 font-mono">{selectedRecruiter.relationship_score} / 100</div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-bold uppercase text-slate-500">Tier Classification</span>
                  <div className="text-xs font-bold text-slate-900 bg-emerald-100 text-emerald-900 px-2.5 py-0.5 rounded border border-emerald-300">
                    {selectedRecruiter.tier_category}
                  </div>
                </div>
              </div>

              {/* Grid Metrics */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <span className="text-[10px] text-slate-500 font-medium">Engagement Years</span>
                  <div className="font-bold text-slate-900 text-sm">{selectedRecruiter.relationship_years} Years</div>
                </div>
                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <span className="text-[10px] text-slate-500 font-medium">Total Students Hired</span>
                  <div className="font-bold text-slate-900 text-sm">{selectedRecruiter.students_hired} Candidates</div>
                </div>
                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <span className="text-[10px] text-slate-500 font-medium">Average Package</span>
                  <div className="font-bold text-emerald-700 text-sm">₹{selectedRecruiter.avg_ctc_lpa} LPA</div>
                </div>
                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <span className="text-[10px] text-slate-500 font-medium">Interview Conversion</span>
                  <div className="font-bold text-slate-900 text-sm">{selectedRecruiter.interview_conversion}%</div>
                </div>
                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <span className="text-[10px] text-slate-500 font-medium">Alumni Working Here</span>
                  <div className="font-bold text-indigo-700 text-sm">{selectedRecruiter.alumni_presence} Alumni</div>
                </div>
                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <span className="text-[10px] text-slate-500 font-medium">Internship Engagement</span>
                  <div className="font-bold text-slate-900 text-sm">{selectedRecruiter.internship_engagement}</div>
                </div>
              </div>

              {/* Roles Offered */}
              <div className="space-y-1">
                <span className="font-bold text-slate-800">Primary Roles Offered:</span>
                <div className="flex flex-wrap gap-1">
                  {selectedRecruiter.primary_roles.map((role, idx) => (
                    <span key={idx} className="bg-slate-100 text-slate-800 border border-slate-200 px-2 py-0.5 rounded text-[11px] font-medium">
                      {role}
                    </span>
                  ))}
                </div>
              </div>

              {/* Key Skills Sought */}
              <div className="space-y-1">
                <span className="font-bold text-slate-800">Key Skills Sought by Recruiter:</span>
                <div className="flex flex-wrap gap-1">
                  {selectedRecruiter.key_skills_sought.map((sk, idx) => (
                    <span key={idx} className="bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded text-[11px] font-semibold">
                      {sk}
                    </span>
                  ))}
                </div>
              </div>

            </div>

            {/* Modal Footer */}
            <div className="p-3 bg-slate-50 border-t border-slate-200 text-right">
              <button
                onClick={() => setSelectedRecruiter(null)}
                className="bg-slate-800 hover:bg-slate-900 text-white font-medium px-4 py-1.5 rounded text-xs cursor-pointer"
              >
                Close Profile
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
