import React, { useState } from 'react';
import { Compass, CheckCircle2, ArrowRight, Lightbulb, GraduationCap } from 'lucide-react';

export const ElectivesPathwaysView: React.FC = () => {
  const [activePathway, setActivePathway] = useState<string>('path_data');

  const pathways = [
    {
      id: 'path_data',
      title: 'Development + Data Analytics Pathway',
      target_sectors: ['Data / Digital Development', 'Research & Consulting', 'CSR'],
      recommended_skills: ['Excel (Advanced)', 'Power BI', 'SQL', 'M&E', 'Data Visualization'],
      recommended_courses: [
        'Big Data & Business Intelligence',
        'Research Methods & Field Inquiry',
        'Monitoring & Evaluation'
      ],
      recommended_certs: ['Advanced Excel for Social Sector', 'Power BI Fundamentals'],
      why_explanation: 'High demand surge (+30% YoY) in digital development and consulting roles with premium CTC packages (₹9.0 – ₹11.5 LPA). Employer feedback indicates students with verified data visualization skills bypass initial screening rounds.'
    },
    {
      id: 'path_livelihoods',
      title: 'Livelihoods + Rural Enterprise Pathway',
      target_sectors: ['Livelihoods', 'Agriculture & Rural Development', 'Cooperatives'],
      recommended_skills: ['Rural Development', 'Livelihoods', 'Cooperatives', 'Project Management', 'Field Research'],
      recommended_courses: [
        'Managing Cooperatives & Producer Organizations',
        'Project Management in Development',
        'Food & Agricultural Marketing'
      ],
      recommended_certs: ['FPO Management Certification', 'Value Chain Analysis'],
      why_explanation: 'DMI\'s highest volume recruiter base (BRLPS/JEEViKA, AKRSP, TechnoServe, SRIJAN). Demonstrating field research and producer organization knowledge ensures over 95% placement conversion.'
    },
    {
      id: 'path_csr',
      title: 'CSR + Programme Management Pathway',
      target_sectors: ['CSR', 'Government Programmes', 'International NGOs'],
      recommended_skills: ['CSR Management', 'M&E', 'Stakeholder Management', 'Project Management', 'Communication'],
      recommended_courses: [
        'Project Management in Development',
        'Monitoring & Evaluation',
        'Social Entrepreneurship & CSR'
      ],
      recommended_certs: ['CSR Policy & Impact Assessment', 'PMD Pro Level 1'],
      why_explanation: 'Corporate philanthropy foundations prioritize structured impact measurement and clear presentation skills. High CTC offerings (₹9.5 – ₹12.0 LPA).'
    },
    {
      id: 'path_finance',
      title: 'Financial Inclusion & Rural Finance Pathway',
      target_sectors: ['Financial Inclusion', 'Microfinance', 'Agri-Finance'],
      recommended_skills: ['Financial Analysis', 'Microfinance', 'Excel', 'Social Sector Knowledge'],
      recommended_courses: [
        'Financial Management for Social Enterprises',
        'Microfinance & Financial Inclusion',
        'Research Methods'
      ],
      recommended_certs: ['Financial Modeling in Excel', 'Credit Risk Analysis'],
      why_explanation: 'Recruiters like NABFINS, COMFED, and rural banks seek candidates capable of conducting credit risk evaluation alongside understanding rural borrower dynamics.'
    }
  ];

  const currentPath = pathways.find(p => p.id === activePathway) || pathways[0];

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="border-b border-slate-200 pb-3">
        <h2 className="text-lg font-bold text-slate-900">Employability Pathways & Elective Recommendations</h2>
        <p className="text-xs text-slate-600">
          Structured skill progression pathways tailored to student career goals and employer requirements
        </p>
      </div>

      {/* Pathway Selection Tabs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
        {pathways.map(p => (
          <button
            key={p.id}
            onClick={() => setActivePathway(p.id)}
            className={`p-3 rounded-lg border text-left text-xs font-semibold transition-all cursor-pointer ${
              activePathway === p.id
                ? 'bg-[#0f2942] text-white border-slate-800 shadow-sm'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center space-x-1.5 mb-1">
              <Compass className={`w-3.5 h-3.5 ${activePathway === p.id ? 'text-emerald-400' : 'text-slate-500'}`} />
              <span className="truncate">{p.title}</span>
            </div>
            <p className={`text-[10px] ${activePathway === p.id ? 'text-slate-300' : 'text-slate-500'}`}>
              {p.target_sectors.slice(0, 2).join(', ')}
            </p>
          </button>
        ))}
      </div>

      {/* Pathway Detail Card */}
      <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs space-y-5">
        
        <div className="border-b border-slate-200 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center space-x-2">
              <GraduationCap className="w-5 h-5 text-indigo-600" />
              <span>{currentPath.title}</span>
            </h3>
            <p className="text-xs text-slate-500">Target Sectors: {currentPath.target_sectors.join(' • ')}</p>
          </div>
          <span className="text-xs bg-emerald-100 text-emerald-900 font-bold px-3 py-1 rounded-full border border-emerald-300">
            Recommended Track
          </span>
        </div>

        {/* Why Recommendation is Made */}
        <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-3.5 text-xs text-indigo-950 space-y-1">
          <div className="font-bold flex items-center space-x-1.5 text-indigo-900">
            <Lightbulb className="w-4 h-4 text-indigo-700" />
            <span>Why is this pathway recommended?</span>
          </div>
          <p className="text-[11px] leading-relaxed text-indigo-900">
            {currentPath.why_explanation}
          </p>
        </div>

        {/* 3 Column Grid: Skills, Courses, Certifications */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          
          {/* Column 1: Skills */}
          <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-2">
            <h4 className="font-bold text-slate-900 uppercase tracking-wider text-[11px] border-b border-slate-200 pb-1.5">
              Target Competencies
            </h4>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {currentPath.recommended_skills.map((sk, idx) => (
                <span key={idx} className="bg-white border border-slate-300 text-slate-800 font-semibold px-2.5 py-1 rounded text-xs shadow-2xs">
                  {sk}
                </span>
              ))}
            </div>
          </div>

          {/* Column 2: Elective Courses */}
          <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-2">
            <h4 className="font-bold text-slate-900 uppercase tracking-wider text-[11px] border-b border-slate-200 pb-1.5">
              Recommended Electives
            </h4>
            <ul className="space-y-1.5 pt-1">
              {currentPath.recommended_courses.map((crs, idx) => (
                <li key={idx} className="flex items-start space-x-2 text-slate-800 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{crs}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Certifications */}
          <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-2">
            <h4 className="font-bold text-slate-900 uppercase tracking-wider text-[11px] border-b border-slate-200 pb-1.5">
              Value-Add Certifications
            </h4>
            <ul className="space-y-1.5 pt-1">
              {currentPath.recommended_certs.map((cert, idx) => (
                <li key={idx} className="flex items-start space-x-2 text-slate-800 font-medium">
                  <ArrowRight className="w-3.5 h-3.5 text-indigo-600 shrink-0 mt-0.5" />
                  <span>{cert}</span>
                </li>
              ))}
            </ul>
          </div>

        </div>

      </div>

    </div>
  );
};
