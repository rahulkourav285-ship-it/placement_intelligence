import React from 'react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import { Student, Recruiter } from '../../types';

interface PlacementDiagnosticsViewProps {
  students: Student[];
  recruiters: Recruiter[];
}

export const PlacementDiagnosticsView: React.FC<PlacementDiagnosticsViewProps> = ({
  students,
  recruiters
}) => {

  // Placement Rate by Batch (Historical Line Chart)
  const batchTrendData = [
    { year: '2021–22', PDM10: 90, PDM11: 88, PDM12: 85 },
    { year: '2022–23', PDM10: 92, PDM11: 91, PDM12: 89 },
    { year: '2023–24', PDM10: 95, PDM11: 93, PDM12: 91 },
    { year: '2024–25', PDM10: 96, PDM11: 95, PDM12: 92 },
    { year: '2025–26', PDM10: 98, PDM11: 96, PDM12: 94 }
  ];

  // Placement Rate by Sector (Horizontal Bar)
  const sectorPlacementData = [
    { sector: 'Livelihoods', rate: 98, avg_ctc: 8.2 },
    { sector: 'CSR', rate: 94, avg_ctc: 9.4 },
    { sector: 'Govt Programmes', rate: 96, avg_ctc: 7.5 },
    { sector: 'Agri & Rural Dev', rate: 92, avg_ctc: 7.9 },
    { sector: 'Research & Consult', rate: 88, avg_ctc: 10.2 },
    { sector: 'Data / Digital', rate: 85, avg_ctc: 9.1 },
    { sector: 'Cooperatives', rate: 95, avg_ctc: 7.2 }
  ];

  // Funnel Data
  const funnelSteps = [
    { stage: 'Applications Submitted', count: 480, dropPct: 0 },
    { stage: 'Shortlisted for Drives', count: 210, dropPct: 56 },
    { stage: 'Interviews Conducted', count: 148, dropPct: 30 },
    { stage: 'Final Offers Received', count: 52, dropPct: 65 },
    { stage: 'Offers Accepted (Placed)', count: 47, dropPct: 10 }
  ];

  // Placement Outcome Matrix rows
  const outcomeMatrix = [
    { category: 'Batch - PDM 12 (Current)', apps: 480, interviews: 148, offers: 52, rate: 94, ctc: 8.4, status: '🟢 Strong' },
    { category: 'Batch - PDM 11 (2024-25)', apps: 450, interviews: 135, offers: 48, rate: 96, ctc: 8.1, status: '🟢 Strong' },
    { category: 'Sector - Livelihoods', apps: 160, interviews: 55, offers: 20, rate: 98, ctc: 8.2, status: '🟢 Strong' },
    { category: 'Sector - CSR & Philanthropy', apps: 110, interviews: 32, offers: 12, rate: 94, ctc: 9.4, status: '🟡 Watch' },
    { category: 'Sector - Data & Digital Dev', apps: 60, interviews: 18, offers: 6, rate: 85, ctc: 9.1, status: '🔴 Intervention Required' },
    { category: 'Gender - Female Candidates', apps: 180, interviews: 58, offers: 21, rate: 95, ctc: 8.5, status: '🟢 Strong' },
    { category: 'Gender - Male Candidates', apps: 300, interviews: 90, offers: 31, rate: 93, ctc: 8.3, status: '🟢 Strong' },
    { category: 'Academic Score - Top 10%', apps: 100, interviews: 45, offers: 18, rate: 100, ctc: 9.8, status: '🟢 Strong' },
    { category: 'Academic Score - Mid Tier', apps: 240, interviews: 70, offers: 24, rate: 92, ctc: 8.0, status: '🟡 Watch' },
    { category: 'Academic Score - Needs Support', apps: 140, interviews: 33, offers: 10, rate: 82, ctc: 7.2, status: '🔴 Intervention Required' }
  ];

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="border-b border-slate-200 pb-3">
        <h2 className="text-lg font-bold text-slate-900">Placement Diagnostics</h2>
        <p className="text-xs text-slate-600">
          Root cause analysis of WHERE placement performance is strong, moderate, or requiring intervention
        </p>
      </div>

      {/* Charts Row 1: Line Chart YoY & Sector Placement Rate */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        
        {/* Placement Rate by Batch Line Chart */}
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs space-y-3">
          <div className="border-b border-slate-100 pb-2">
            <h3 className="text-xs font-bold text-slate-800">Placement Rate Trajectory by Batch</h3>
            <p className="text-[11px] text-slate-500">Historical placement progression (2021–26)</p>
          </div>
          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={batchTrendData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="year" tick={{ fontSize: 10, fill: '#475569' }} />
                <YAxis domain={[75, 100]} tick={{ fontSize: 10, fill: '#475569' }} />
                <Tooltip contentStyle={{ backgroundColor: '#0f2942', borderRadius: '4px', color: '#fff', fontSize: '11px' }} />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Line type="monotone" dataKey="PDM12" name="PDM 12 (Current)" stroke="#15803d" strokeWidth={2.5} activeDot={{ r: 6 }} />
                <Line type="monotone" dataKey="PDM11" name="PDM 11 (2024-25)" stroke="#1e40af" strokeWidth={2} strokeDasharray="4 4" />
                <Line type="monotone" dataKey="PDM10" name="PDM 10 (2023-24)" stroke="#64748b" strokeWidth={1.5} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Placement Rate by Sector Bar Chart */}
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs space-y-3">
          <div className="border-b border-slate-100 pb-2">
            <h3 className="text-xs font-bold text-slate-800">Placement Rate by Development Sector</h3>
            <p className="text-[11px] text-slate-500">Percentage of candidates placed per domain</p>
          </div>
          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={sectorPlacementData} layout="vertical" margin={{ top: 5, right: 20, left: 30, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
                <XAxis type="number" domain={[70, 100]} tick={{ fontSize: 10, fill: '#475569' }} />
                <YAxis dataKey="sector" type="category" tick={{ fontSize: 10, fill: '#334155' }} width={110} />
                <Tooltip formatter={(val: any) => [`${val}% Placed`, 'Placement Rate']} contentStyle={{ backgroundColor: '#0f2942', borderRadius: '4px', color: '#fff', fontSize: '11px' }} />
                <Bar dataKey="rate" fill="#1e3a8a" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

      {/* Row 2: Average CTC by Sector & Interview-to-Offer Funnel */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        
        {/* Average CTC by Sector */}
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs space-y-3">
          <div className="border-b border-slate-100 pb-2">
            <h3 className="text-xs font-bold text-slate-800">Average CTC Compensation by Sector (LPA)</h3>
            <p className="text-[11px] text-slate-500">Comparative compensation packages across development domains</p>
          </div>
          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={sectorPlacementData} margin={{ top: 10, right: 20, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="sector" tick={{ fontSize: 9, fill: '#334155' }} interval={0} />
                <YAxis domain={[0, 12]} tick={{ fontSize: 10, fill: '#475569' }} />
                <Tooltip formatter={(val: any) => [`₹${val} LPA`, 'Average CTC']} contentStyle={{ backgroundColor: '#0f2942', borderRadius: '4px', color: '#fff', fontSize: '11px' }} />
                <Bar dataKey="avg_ctc" fill="#0d9488" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Funnel: Applications -> Shortlist -> Interview -> Offer -> Accepted */}
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs space-y-3">
          <div className="border-b border-slate-100 pb-2">
            <h3 className="text-xs font-bold text-slate-800">Interview-to-Offer Conversion Funnel</h3>
            <p className="text-[11px] text-slate-500">Stage-by-stage candidate drop-off analysis</p>
          </div>
          
          <div className="space-y-2 py-1">
            {funnelSteps.map((step, idx) => {
              const maxCount = 480;
              const widthPct = Math.max(15, Math.round((step.count / maxCount) * 100));
              return (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between text-[11px] font-medium text-slate-700">
                    <span>{step.stage}</span>
                    <span className="font-bold text-slate-900">{step.count} candidates</span>
                  </div>
                  <div className="w-full bg-slate-100 h-6 rounded overflow-hidden flex items-center">
                    <div
                      className="bg-[#0f2942] h-full transition-all duration-300 flex items-center justify-end px-2 text-white font-bold text-[10px]"
                      style={{ width: `${widthPct}%` }}
                    >
                      {widthPct}%
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>

      {/* Placement Outcome Matrix Table */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Placement Outcome Diagnostic Matrix</h3>
            <p className="text-[11px] text-slate-500">Detailed performance breakdown with intervention flags</p>
          </div>
          <span className="text-[11px] font-mono text-slate-500 bg-white border border-slate-200 px-2 py-0.5 rounded">
            Filtered View: PDM 12
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                <th className="p-3">Category Breakdown</th>
                <th className="p-3 text-right">Applications</th>
                <th className="p-3 text-right">Interviews</th>
                <th className="p-3 text-right">Offers Made</th>
                <th className="p-3 text-right">Placement Rate</th>
                <th className="p-3 text-right">Avg CTC (LPA)</th>
                <th className="p-3 text-center">Diagnostic Flag</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-800">
              {outcomeMatrix.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-50 transition-colors">
                  <td className="p-3 font-semibold text-slate-900">{row.category}</td>
                  <td className="p-3 text-right font-mono text-slate-600">{row.apps}</td>
                  <td className="p-3 text-right font-mono text-slate-600">{row.interviews}</td>
                  <td className="p-3 text-right font-mono text-slate-600">{row.offers}</td>
                  <td className="p-3 text-right font-bold text-slate-900">{row.rate}%</td>
                  <td className="p-3 text-right font-semibold text-emerald-700">₹{row.ctc}</td>
                  <td className="p-3 text-center">
                    <span className={`inline-block px-2.5 py-0.5 text-[11px] font-bold rounded-full border ${
                      row.status.includes('Strong') ? 'bg-emerald-50 text-emerald-800 border-emerald-200' :
                      row.status.includes('Watch') ? 'bg-amber-50 text-amber-800 border-amber-200' :
                      'bg-rose-50 text-rose-800 border-rose-200'
                    }`}>
                      {row.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
