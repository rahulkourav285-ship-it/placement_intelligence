import React from 'react';

interface GaugeChartProps {
  value: number; // percentage e.g. 94 or 32
  min?: number;
  max?: number;
  title: string;
  subtitle?: string;
  color?: string;
  unit?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const GaugeChart: React.FC<GaugeChartProps> = ({
  value,
  min = 0,
  max = 100,
  title,
  subtitle,
  color = '#002B5B',
  unit = '%',
  size = 'md'
}) => {
  const percentage = Math.min(Math.max(((value - min) / (max - min)) * 100, 0), 100);
  
  // Angle for SVG arc (180 degrees semi-circle)
  const angle = (percentage / 100) * 180;
  
  // Radius and center parameters based on size
  const strokeWidth = size === 'sm' ? 12 : size === 'lg' ? 18 : 14;
  const radius = size === 'sm' ? 45 : size === 'lg' ? 75 : 60;
  const cx = size === 'sm' ? 60 : size === 'lg' ? 95 : 80;
  const cy = size === 'sm' ? 55 : size === 'lg' ? 90 : 75;
  const svgWidth = size === 'sm' ? 120 : size === 'lg' ? 190 : 160;
  const svgHeight = size === 'sm' ? 75 : size === 'lg' ? 115 : 95;

  // Arc path generator
  const getArcPath = (startAngle: number, endAngle: number) => {
    const startRad = (Math.PI / 180) * (180 + startAngle);
    const endRad = (Math.PI / 180) * (180 + endAngle);
    
    const x1 = cx + radius * Math.cos(startRad);
    const y1 = cy + radius * Math.sin(startRad);
    const x2 = cx + radius * Math.cos(endRad);
    const y2 = cy + radius * Math.sin(endRad);
    
    const largeArcFlag = endAngle - startAngle <= 180 ? '0' : '1';
    
    return `M ${x1} ${y1} A ${radius} ${radius} 0 ${largeArcFlag} 1 ${x2} ${y2}`;
  };

  const getGaugeColor = (pct: number) => {
    if (color && color !== '#002B5B') return color;
    if (pct >= 80) return '#4C7031'; // DMI Green
    if (pct >= 60) return '#002B5B'; // DMI Navy
    if (pct >= 40) return '#D97706'; // Amber
    return '#DC2626'; // Red
  };

  const activeColor = getGaugeColor(percentage);

  return (
    <div className="bg-white p-4 rounded border border-gray-200 shadow-xs flex flex-col items-center justify-between transition-all hover:border-[#002B5B]/30">
      <div className="text-center mb-1">
        <h4 className="text-xs font-bold text-[#002B5B] uppercase tracking-wider">{title}</h4>
        {subtitle && <p className="text-[10px] text-gray-500 leading-tight">{subtitle}</p>}
      </div>

      <div className="relative flex items-center justify-center my-1">
        <svg width={svgWidth} height={svgHeight} className="overflow-visible">
          {/* Background Gray Arc */}
          <path
            d={getArcPath(0, 180)}
            fill="none"
            stroke="#E5E7EB"
            strokeWidth={strokeWidth}
            strokeLinecap="round"
          />
          {/* Active Percentage Arc */}
          {percentage > 0 && (
            <path
              d={getArcPath(0, angle)}
              fill="none"
              stroke={activeColor}
              strokeWidth={strokeWidth}
              strokeLinecap="round"
              className="transition-all duration-700 ease-out"
            />
          )}
        </svg>

        {/* Central Value Text */}
        <div className="absolute bottom-1 flex flex-col items-center justify-center">
          <span className="text-xl sm:text-2xl font-black text-[#002B5B] tracking-tight">
            {value}
            <span className="text-xs font-bold text-gray-500 ml-0.5">{unit}</span>
          </span>
        </div>
      </div>

      {/* Min / Max Labels */}
      <div className="w-full flex items-center justify-between text-[9px] text-gray-400 font-medium px-2 mt-1">
        <span>{min}{unit}</span>
        <span className="font-bold" style={{ color: activeColor }}>
          {percentage.toFixed(0)}% Target
        </span>
        <span>{max}{unit}</span>
      </div>
    </div>
  );
};
