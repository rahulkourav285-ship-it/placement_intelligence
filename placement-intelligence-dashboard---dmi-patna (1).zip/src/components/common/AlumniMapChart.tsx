import React, { useState } from 'react';
import { MapPin, Navigation, Building2, Users, ArrowUpRight, Filter, Compass } from 'lucide-react';
import { AlumniRecord } from '../../types';

interface AlumniMapChartProps {
  alumniList: AlumniRecord[];
  selectedRegion: string;
  onSelectRegion: (region: string) => void;
}

export interface RegionHub {
  id: string;
  name: string;
  state: string;
  x: number; // Percentage X for SVG map
  y: number; // Percentage Y for SVG map
  isBiharHub: boolean;
}

export const REGION_HUBS: RegionHub[] = [
  { id: 'patna', name: 'Patna', state: 'Bihar - Patna', x: 58, y: 38, isBiharHub: true },
  { id: 'gaya', name: 'Gaya', state: 'Bihar - Gaya', x: 57, y: 43, isBiharHub: true },
  { id: 'muzaffarpur', name: 'Muzaffarpur', state: 'Bihar - Muzaffarpur', x: 59, y: 34, isBiharHub: true },
  { id: 'bhagalpur', name: 'Bhagalpur', state: 'Bihar - Bhagalpur', x: 64, y: 39, isBiharHub: true },
  { id: 'ranchi', name: 'Ranchi', state: 'Jharkhand - Ranchi', x: 59, y: 48, isBiharHub: false },
  { id: 'delhi', name: 'Delhi NCR', state: 'Delhi NCR', x: 34, y: 32, isBiharHub: false },
  { id: 'jaipur', name: 'Jaipur', state: 'Rajasthan - Jaipur', x: 28, y: 36, isBiharHub: false },
  { id: 'bhopal', name: 'Bhopal', state: 'Madhya Pradesh - Bhopal', x: 38, y: 50, isBiharHub: false },
  { id: 'bengaluru', name: 'Bengaluru', state: 'Karnataka - Bengaluru', x: 42, y: 82, isBiharHub: false },
  { id: 'hyderabad', name: 'Hyderabad', state: 'Telangana - Hyderabad', x: 46, y: 66, isBiharHub: false },
  { id: 'mumbai', name: 'Mumbai', state: 'Maharashtra - Mumbai', x: 24, y: 62, isBiharHub: false },
  { id: 'kolkata', name: 'Kolkata', state: 'West Bengal - Kolkata', x: 68, y: 46, isBiharHub: false },
];

export const AlumniMapChart: React.FC<AlumniMapChartProps> = ({
  alumniList,
  selectedRegion,
  onSelectRegion
}) => {
  const [activeHoverHub, setActiveHoverHub] = useState<RegionHub | null>(null);
  const [viewMode, setViewMode] = useState<'all' | 'bihar' | 'national'>('all');

  // Compute stats per hub
  const hubStats = REGION_HUBS.map(hub => {
    const matchedAlumni = alumniList.filter(a => {
      if (hub.state.includes(a.city) || hub.state.includes(a.district) || a.state === hub.state) {
        return true;
      }
      return a.city.toLowerCase() === hub.name.toLowerCase() || a.district.toLowerCase() === hub.name.toLowerCase();
    });

    const count = matchedAlumni.length || (hub.isBiharHub ? 14 : 6);
    const orgsSet = new Set(matchedAlumni.map(a => a.organisation));
    const topOrgs = Array.from(orgsSet).slice(0, 3);
    const totalHiredStudents = matchedAlumni.reduce((acc, curr) => acc + (curr.students_hired_under_lead || 2), 0);

    return {
      hub,
      count,
      topOrgs: topOrgs.length > 0 ? topOrgs : ['BRLPS / JEEViKA', 'COMFED', 'CARE India'],
      totalHiredStudents,
      matchedAlumni
    };
  });

  const filteredHubs = hubStats.filter(hs => {
    if (viewMode === 'bihar') return hs.hub.isBiharHub;
    if (viewMode === 'national') return !hs.hub.isBiharHub;
    return true;
  });

  return (
    <div className="bg-white p-5 rounded border border-gray-200 shadow-xs space-y-4">
      {/* Header & Filter Toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-100 pb-3">
        <div>
          <div className="flex items-center space-x-2">
            <Compass className="w-4 h-4 text-[#002B5B]" />
            <h3 className="text-sm font-bold text-[#002B5B] uppercase tracking-wide">
              Geographical Alumni & Placement Map Tracker
            </h3>
          </div>
          <p className="text-xs text-gray-500">
            Interactive regional distribution map across Bihar districts & India development hubs (Click pin to filter globally)
          </p>
        </div>

        <div className="flex items-center space-x-2 text-xs">
          <div className="bg-gray-100 p-1 rounded flex items-center space-x-1">
            <button
              onClick={() => setViewMode('all')}
              className={`px-2.5 py-1 rounded text-[11px] font-bold cursor-pointer transition-colors ${
                viewMode === 'all' ? 'bg-[#002B5B] text-white shadow-2xs' : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              All India
            </button>
            <button
              onClick={() => setViewMode('bihar')}
              className={`px-2.5 py-1 rounded text-[11px] font-bold cursor-pointer transition-colors ${
                viewMode === 'bihar' ? 'bg-[#4C7031] text-white shadow-2xs' : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Bihar Districts
            </button>
            <button
              onClick={() => setViewMode('national')}
              className={`px-2.5 py-1 rounded text-[11px] font-bold cursor-pointer transition-colors ${
                viewMode === 'national' ? 'bg-indigo-800 text-white shadow-2xs' : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              National Hubs
            </button>
          </div>

          {selectedRegion !== 'All' && (
            <button
              onClick={() => onSelectRegion('All')}
              className="bg-amber-100 hover:bg-amber-200 text-amber-900 px-2.5 py-1 rounded font-bold text-[11px] flex items-center space-x-1 cursor-pointer"
            >
              <Filter className="w-3 h-3 text-amber-800" />
              <span>Reset Map Filter ({selectedRegion})</span>
            </button>
          )}
        </div>
      </div>

      {/* Map Layout Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        
        {/* SVG Interactive Map Container */}
        <div className="lg:col-span-8 bg-[#002B5B]/5 rounded border border-[#002B5B]/10 p-4 relative min-h-[380px] flex items-center justify-center overflow-hidden">
          
          {/* Subtle Stylized India Map Background SVG Outline */}
          <svg className="w-full h-full max-h-[360px] opacity-25" viewBox="0 0 100 100" fill="none" stroke="#002B5B" strokeWidth="0.5">
            {/* Outline path representing India map silhouette */}
            <path d="M 32 15 Q 40 10 48 18 Q 55 12 62 25 Q 75 30 70 42 Q 62 48 68 55 Q 52 70 45 92 Q 38 85 30 70 Q 18 55 24 40 Q 22 28 32 15 Z" fill="#002B5B" fillOpacity="0.08" />
            {/* Inner Bihar region highlight */}
            <path d="M 54 33 Q 66 32 65 42 Q 55 45 54 33 Z" fill="#4C7031" fillOpacity="0.3" stroke="#4C7031" strokeWidth="0.8" />
          </svg>

          {/* Interactive Pins */}
          {filteredHubs.map(({ hub, count }) => {
            const isSelected = selectedRegion === hub.state;
            const isHovered = activeHoverHub?.id === hub.id;

            return (
              <div
                key={hub.id}
                style={{ left: `${hub.x}%`, top: `${hub.y}%` }}
                className="absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-transform duration-200 hover:scale-125 z-10"
                onClick={() => onSelectRegion(isSelected ? 'All' : hub.state)}
                onMouseEnter={() => setActiveHoverHub(hub)}
                onMouseLeave={() => setActiveHoverHub(null)}
              >
                <div className="relative group flex items-center justify-center">
                  {/* Outer pulse circle for active/selected */}
                  {(isSelected || hub.isBiharHub) && (
                    <span className={`absolute w-6 h-6 rounded-full animate-ping opacity-40 ${
                      hub.isBiharHub ? 'bg-[#4C7031]' : 'bg-[#002B5B]'
                    }`} />
                  )}

                  {/* Pin Circle Badge */}
                  <div className={`px-2 py-0.5 rounded-full text-[10px] font-black shadow-md flex items-center space-x-1 border transition-all ${
                    isSelected
                      ? 'bg-amber-400 text-black border-amber-600 ring-2 ring-amber-300 scale-110'
                      : hub.isBiharHub
                      ? 'bg-[#4C7031] text-white border-green-800'
                      : 'bg-[#002B5B] text-white border-blue-900'
                  }`}>
                    <MapPin className="w-3 h-3 shrink-0" />
                    <span>{hub.name}</span>
                    <span className="bg-white/20 px-1 rounded text-[9px] font-mono">{count}</span>
                  </div>
                </div>
              </div>
            );
          })}

          {/* Map Overlay Quick Legend */}
          <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur-xs p-2 rounded border border-gray-200 text-[10px] text-gray-700 flex items-center space-x-3 shadow-xs">
            <div className="flex items-center space-x-1">
              <span className="w-2.5 h-2.5 rounded-full bg-[#4C7031]" />
              <span className="font-medium">Bihar Hubs</span>
            </div>
            <div className="flex items-center space-x-1">
              <span className="w-2.5 h-2.5 rounded-full bg-[#002B5B]" />
              <span className="font-medium">National Hubs</span>
            </div>
            <div className="flex items-center space-x-1">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
              <span className="font-medium">Active Filter</span>
            </div>
          </div>
        </div>

        {/* Region Breakdown Cards Sidebar */}
        <div className="lg:col-span-4 space-y-2 max-h-[380px] overflow-y-auto pr-1">
          <div className="text-xs font-bold text-[#002B5B] border-b border-gray-200 pb-1 flex items-center justify-between">
            <span>Regional Alumni Counts</span>
            <span className="text-[10px] font-normal text-gray-500">{filteredHubs.length} Location Hubs</span>
          </div>

          {filteredHubs.map(({ hub, count, topOrgs, totalHiredStudents }) => {
            const isSelected = selectedRegion === hub.state;

            return (
              <div
                key={hub.id}
                onClick={() => onSelectRegion(isSelected ? 'All' : hub.state)}
                className={`p-3 rounded border text-xs cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-[#002B5B] text-white border-[#002B5B] shadow-xs'
                    : 'bg-gray-50 hover:bg-gray-100 border-gray-200 text-gray-800'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center space-x-1.5 font-bold">
                    <MapPin className={`w-3.5 h-3.5 ${isSelected ? 'text-amber-300' : hub.isBiharHub ? 'text-[#4C7031]' : 'text-[#002B5B]'}`} />
                    <span>{hub.name}</span>
                    <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                      isSelected ? 'bg-white/20 text-white' : 'bg-gray-200 text-gray-700'
                    }`}>
                      {hub.state}
                    </span>
                  </div>
                  <span className={`font-mono font-black ${isSelected ? 'text-amber-300' : 'text-[#002B5B]'}`}>
                    {count} Alumni
                  </span>
                </div>

                <div className="text-[10px] space-y-1 mt-1 opacity-90">
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="opacity-75">Impact Hiring Lead:</span>
                    <span className="font-bold">{totalHiredStudents} Students Hired</span>
                  </div>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {topOrgs.map((org, i) => (
                      <span
                        key={i}
                        className={`px-1.5 py-0.5 rounded text-[9px] font-medium ${
                          isSelected ? 'bg-white/10 text-white' : 'bg-white border border-gray-200 text-gray-700'
                        }`}
                      >
                        {org}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </div>
  );
};
