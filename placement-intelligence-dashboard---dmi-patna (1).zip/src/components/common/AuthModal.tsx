import React, { useState } from 'react';
import { Phone, Mail, Shield, CheckCircle2, Lock, ArrowRight, X, User, RefreshCw, KeyRound } from 'lucide-react';
import { UserRole, UserAuth } from '../../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: UserAuth) => void;
  currentRole: UserRole;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
  currentRole
}) => {
  const [authMethod, setAuthMethod] = useState<'mobile' | 'google'>('mobile');
  
  // Mobile OTP States
  const [phoneNumber, setPhoneNumber] = useState('9876543210');
  const [selectedRole, setSelectedRole] = useState<UserRole>(currentRole);
  const [userName, setUserName] = useState('Rahul Kourav');
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState(['8', '4', '9', '2', '0', '1']);
  const [isVerifying, setIsVerifying] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [resendTimer, setResendTimer] = useState(30);

  // Google State
  const [googleEmail, setGoogleEmail] = useState('rahulkourav285@gmail.com');

  if (!isOpen) return null;

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneNumber || phoneNumber.length < 10) {
      setErrorMessage('Please enter a valid 10-digit mobile number.');
      return;
    }
    setErrorMessage('');
    setOtpSent(true);
    setResendTimer(30);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setIsVerifying(true);
    
    setTimeout(() => {
      setIsVerifying(false);
      onLoginSuccess({
        isLoggedIn: true,
        authMethod: 'mobile',
        phoneNumber,
        name: userName || 'Authenticated User',
        role: selectedRole,
        avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'
      });
      onClose();
    }, 600);
  };

  const handleGoogleLogin = () => {
    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      onLoginSuccess({
        isLoggedIn: true,
        authMethod: 'google',
        email: googleEmail,
        name: userName || 'Rahul Kourav',
        role: selectedRole,
        avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80'
      });
      onClose();
    }, 700);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-fadeIn">
      <div className="bg-white rounded-lg shadow-2xl border border-gray-200 w-full max-w-md overflow-hidden relative">
        
        {/* Header Bar */}
        <div className="bg-[#002B5B] text-white p-5 flex items-center justify-between border-b border-[#002B5B]">
          <div className="flex items-center space-x-2">
            <Shield className="w-5 h-5 text-[#4C7031]" />
            <div>
              <h3 className="text-sm font-bold tracking-tight">DMI Patna Portal Access</h3>
              <p className="text-[10px] text-gray-300">Placement Cell Secure OTP & Google Authentication</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-300 hover:text-white p-1 rounded hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Method Toggle Tabs */}
        <div className="flex border-b border-gray-200 bg-gray-50 text-xs font-bold text-gray-600">
          <button
            onClick={() => { setAuthMethod('mobile'); setOtpSent(false); }}
            className={`flex-1 py-3 px-4 flex items-center justify-center space-x-2 border-b-2 cursor-pointer transition-colors ${
              authMethod === 'mobile'
                ? 'border-[#002B5B] text-[#002B5B] bg-white'
                : 'border-transparent hover:text-gray-900'
            }`}
          >
            <Phone className="w-4 h-4 text-[#002B5B]" />
            <span>Mobile No OTP</span>
          </button>

          <button
            onClick={() => setAuthMethod('google')}
            className={`flex-1 py-3 px-4 flex items-center justify-center space-x-2 border-b-2 cursor-pointer transition-colors ${
              authMethod === 'google'
                ? 'border-[#002B5B] text-[#002B5B] bg-white'
                : 'border-transparent hover:text-gray-900'
            }`}
          >
            <Mail className="w-4 h-4 text-rose-600" />
            <span>Google Account</span>
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 space-y-4">
          
          {/* User Role Selection */}
          <div>
            <label className="block text-[11px] font-bold text-[#002B5B] uppercase tracking-wider mb-1">
              Select Institutional Role
            </label>
            <select
              value={selectedRole}
              onChange={(e) => setSelectedRole(e.target.value as UserRole)}
              className="w-full text-xs font-bold bg-gray-50 border border-gray-300 rounded p-2.5 text-gray-800 focus:ring-2 focus:ring-[#002B5B] outline-none"
            >
              <option value="placement_cell">Placement Cell Administrator</option>
              <option value="leadership">Institutional Leadership / Director</option>
              <option value="academic_team">Academic Faculty / PDM Chairperson</option>
              <option value="student">Student / Batch Representative View</option>
            </select>
          </div>

          {/* User Full Name Input */}
          <div>
            <label className="block text-[11px] font-bold text-[#002B5B] uppercase tracking-wider mb-1">
              Full Name
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
              <input
                type="text"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                placeholder="Enter full name"
                className="w-full text-xs pl-9 pr-3 py-2.5 bg-white border border-gray-300 rounded font-medium text-gray-800 focus:ring-2 focus:ring-[#002B5B] outline-none"
              />
            </div>
          </div>

          {/* MOBILE OTP FLOW */}
          {authMethod === 'mobile' && (
            <div>
              {!otpSent ? (
                <form onSubmit={handleSendOtp} className="space-y-3">
                  <div>
                    <label className="block text-[11px] font-bold text-[#002B5B] uppercase tracking-wider mb-1">
                      Mobile Number
                    </label>
                    <div className="flex items-center space-x-2">
                      <span className="bg-gray-100 border border-gray-300 text-xs font-bold text-gray-700 px-3 py-2.5 rounded">
                        +91
                      </span>
                      <input
                        type="tel"
                        maxLength={10}
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, ''))}
                        placeholder="10 digit mobile number"
                        className="flex-1 text-xs px-3 py-2.5 bg-white border border-gray-300 rounded font-mono font-bold text-gray-900 focus:ring-2 focus:ring-[#002B5B] outline-none"
                      />
                    </div>
                  </div>

                  {errorMessage && (
                    <p className="text-[11px] font-bold text-rose-600">{errorMessage}</p>
                  )}

                  <button
                    type="submit"
                    className="w-full bg-[#002B5B] hover:bg-[#002B5B]/90 text-white font-bold text-xs py-3 rounded shadow-xs flex items-center justify-center space-x-2 transition-colors cursor-pointer"
                  >
                    <span>Send 6-Digit Verification OTP</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </form>
              ) : (
                <form onSubmit={handleVerifyOtp} className="space-y-4 animate-fadeIn">
                  <div className="bg-emerald-50 border border-emerald-200 p-3 rounded text-xs text-emerald-900 space-y-1">
                    <div className="flex items-center space-x-1.5 font-bold">
                      <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                      <span>OTP Sent Successfully!</span>
                    </div>
                    <p className="text-[10px] text-emerald-800">
                      Verification SMS sent to <strong>+91 {phoneNumber}</strong>.
                    </p>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-[#002B5B] uppercase tracking-wider mb-2">
                      Enter 6-Digit OTP Code
                    </label>
                    <div className="flex items-center justify-between gap-1.5">
                      {otpCode.map((digit, idx) => (
                        <input
                          key={idx}
                          type="text"
                          maxLength={1}
                          value={digit}
                          onChange={(e) => {
                            const newOtp = [...otpCode];
                            newOtp[idx] = e.target.value;
                            setOtpCode(newOtp);
                          }}
                          className="w-10 h-11 text-center font-mono font-bold text-lg bg-gray-50 border border-gray-300 rounded text-[#002B5B] focus:ring-2 focus:ring-[#002B5B] outline-none"
                        />
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-gray-500">
                    <span>Demo OTP Code: <strong className="font-mono text-gray-900">849201</strong></span>
                    <button
                      type="button"
                      onClick={() => setOtpSent(false)}
                      className="text-[#002B5B] font-bold hover:underline cursor-pointer"
                    >
                      Change Number
                    </button>
                  </div>

                  <button
                    type="submit"
                    disabled={isVerifying}
                    className="w-full bg-[#4C7031] hover:bg-[#385423] text-white font-bold text-xs py-3 rounded shadow-xs flex items-center justify-center space-x-2 transition-colors cursor-pointer"
                  >
                    {isVerifying ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <>
                        <KeyRound className="w-4 h-4" />
                        <span>Verify OTP & Access System</span>
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          )}

          {/* GOOGLE FLOW */}
          {authMethod === 'google' && (
            <div className="space-y-4">
              <div>
                <label className="block text-[11px] font-bold text-[#002B5B] uppercase tracking-wider mb-1">
                  Institutional Email Address
                </label>
                <input
                  type="email"
                  value={googleEmail}
                  onChange={(e) => setGoogleEmail(e.target.value)}
                  placeholder="name@dmi.ac.in or gmail.com"
                  className="w-full text-xs px-3 py-2.5 bg-white border border-gray-300 rounded font-medium text-gray-900 focus:ring-2 focus:ring-[#002B5B] outline-none"
                />
              </div>

              <div className="bg-blue-50 border border-blue-200 p-3 rounded text-xs text-blue-950 flex items-start space-x-2">
                <Lock className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
                <p className="text-[11px]">
                  Google Single Sign-On grants secure access according to your institutional email credentials and role.
                </p>
              </div>

              <button
                onClick={handleGoogleLogin}
                disabled={isVerifying}
                className="w-full bg-white hover:bg-gray-50 text-gray-800 border border-gray-300 font-bold text-xs py-3 rounded shadow-xs flex items-center justify-center space-x-3 transition-colors cursor-pointer"
              >
                {isVerifying ? (
                  <RefreshCw className="w-4 h-4 animate-spin text-[#002B5B]" />
                ) : (
                  <>
                    <svg className="w-4 h-4" viewBox="0 0 24 24">
                      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                    </svg>
                    <span>Continue with Google Sign-In</span>
                  </>
                )}
              </button>
            </div>
          )}

          {/* Footer note */}
          <p className="text-[10px] text-gray-500 text-center pt-2 border-t border-gray-100">
            Development Management Institute (DMI), Patna — Placement Decision Support System
          </p>

        </div>
      </div>
    </div>
  );
};
