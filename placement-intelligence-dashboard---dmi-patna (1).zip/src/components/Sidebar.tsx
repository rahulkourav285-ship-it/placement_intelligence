import React from 'react';
import {
  LayoutDashboard,
  BarChart3,
  Target,
  FileCheck2,
  Users,
  Building2,
  TrendingUp,
  Briefcase,
  BookOpen,
  GraduationCap,
  Compass,
  Network,
  Share2,
  Lightbulb,
  ShieldCheck,
  ChevronRight,
  Menu,
  X
} from 'lucide-react';

export type NavTab =
  | 'executive'
  | 'placement_diagnostics'
  | 'skill_gap'
  | 'interview_analytics'
  | 'student_employability'
  | 'recruiter_intelligence'
  | 'sector_trends'
  | 'job_demand'
  | 'curriculum_alignment'
  | 'electives_certifications'
  | 'internship_alignment'
  | 'alumni_intelligence'
  | 'recruiter_map'
  | 'recommendations'
  | 'data_quality';

interface SidebarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  isOpenMobile: boolean;
  setIsOpenMobile: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  isOpenMobile,
  setIsOpenMobile
}) => {
  const sections = [
    {
      title: 'OVERVIEW',
      items: [
        { id: 'executive' as NavTab, label: 'Executive Dashboard', icon: LayoutDashboard }
      ]
    },
    {
      title: 'DIAGNOSTICS',
      items: [
        { id: 'placement_diagnostics' as NavTab, label: 'Placement Diagnostics', icon: BarChart3 },
        { id: 'skill_gap' as NavTab, label: 'Skill Gap Analysis', icon: Target },
        { id: 'interview_analytics' as NavTab, label: 'Interview Analytics', icon: FileCheck2 },
        { id: 'student_employability' as NavTab, label: 'Student Employability', icon: Users }
      ]
    },
    {
      title: 'MARKET INTELLIGENCE',
      items: [
        { id: 'recruiter_intelligence' as NavTab, label: 'Recruiter Intelligence', icon: Building2 },
        { id: 'sector_trends' as NavTab, label: 'Sector Hiring Trends', icon: TrendingUp },
        { id: 'job_demand' as NavTab, label: 'Job / Skill Demand', icon: Briefcase }
      ]
    },
    {
      title: 'CURRICULUM',
      items: [
        { id: 'curriculum_alignment' as NavTab, label: 'Curriculum Alignment', icon: BookOpen },
        { id: 'electives_certifications' as NavTab, label: 'Electives & Certifications', icon: GraduationCap },
        { id: 'internship_alignment' as NavTab, label: 'Internship Alignment', icon: Compass }
      ]
    },
    {
      title: 'NETWORK',
      items: [
        { id: 'alumni_intelligence' as NavTab, label: 'Alumni Intelligence', icon: Network },
        { id: 'recruiter_map' as NavTab, label: 'Recruiter Relationship Map', icon: Share2 }
      ]
    },
    {
      title: 'DECISION SUPPORT',
      items: [
        { id: 'recommendations' as NavTab, label: 'Strategic Recommendations', icon: Lightbulb },
        { id: 'data_quality' as NavTab, label: 'Data Quality & Governance', icon: ShieldCheck }
      ]
    }
  ];

  const handleTabClick = (tabId: NavTab) => {
    setActiveTab(tabId);
    setIsOpenMobile(false);
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div
          className="fixed inset-0 bg-slate-900/60 z-40 lg:hidden backdrop-blur-xs"
          onClick={() => setIsOpenMobile(false)}
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed lg:sticky top-0 lg:top-[57px] left-0 h-screen lg:h-[calc(100vh-57px)] w-64 bg-[#002B5B] text-white z-50 lg:z-10 flex flex-col transition-transform duration-200 ease-in-out ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Sidebar Brand Header */}
        <div className="p-5 border-b border-[#ffffff22] flex items-center justify-between">
          <div>
            <h1 className="text-lg font-bold leading-tight text-white">DMI Patna</h1>
            <p className="text-[10px] uppercase tracking-wider opacity-70 text-white">Placement Intelligence</p>
          </div>
          <button
            onClick={() => setIsOpenMobile(false)}
            className="p-1 rounded text-white/70 hover:text-white lg:hidden cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Navigation Items */}
        <div className="flex-1 overflow-y-auto py-3 space-y-4 text-xs scrollbar-thin">
          {sections.map((section, idx) => (
            <div key={idx} className="space-y-1">
              <h3 className="px-5 text-[10px] uppercase font-bold tracking-wider opacity-60 text-white">
                {section.title}
              </h3>
              <div className="space-y-0.5 mt-1">
                {section.items.map(item => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleTabClick(item.id)}
                      className={`w-full flex items-center justify-between px-5 py-2 text-xs transition-all cursor-pointer text-left ${
                        isActive
                          ? 'bg-[#ffffff15] text-white font-bold border-l-4 border-[#4C7031]'
                          : 'text-white/80 hover:text-white hover:bg-[#ffffff08]'
                      }`}
                    >
                      <div className="flex items-center space-x-2.5 truncate">
                        <Icon className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-white' : 'text-white/70'}`} />
                        <span className="truncate">{item.label}</span>
                      </div>
                      {isActive && <ChevronRight className="w-3.5 h-3.5 text-[#4C7031] shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Sidebar Footer Info */}
        <div className="p-5 border-t border-[#ffffff11] text-[11px] text-white/70 bg-[#002248]">
          <div className="flex items-center space-x-2 text-[10px]">
            <div className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></div>
            <span className="font-semibold text-white">Demo Mode Active</span>
          </div>
          <p className="mt-1 text-[9px] opacity-60">DMI Patna Placement MIS v2.5</p>
        </div>
      </aside>
    </>
  );
};
