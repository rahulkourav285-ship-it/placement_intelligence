import React from 'react';
import { Download, RefreshCw, Database, ShieldAlert, Sparkles, UserCheck } from 'lucide-react';
import { ACADEMIC_YEARS, BATCHES } from '../data/mockData';
import { FilterState, UserRole } from '../types';

interface HeaderProps {
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  onExportPDF: () => void;
  onOpenAskData: () => void;
  onHomeClick: () => void;
  onOpenAuthModal: () => void;
  isLoggedIn: boolean;
  userName?: string;
}

export const Header: React.FC<HeaderProps> = ({
  filters,
  setFilters,
  userRole,
  setUserRole,
  onExportPDF,
  onOpenAskData,
  onHomeClick,
  onOpenAuthModal,
  isLoggedIn,
  userName
}) => {
  return (
    <header className="bg-white text-[#2D3436] border-b border-gray-200 shadow-xs sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
          
          {/* Left Title Area */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={onHomeClick}>
            <div className="bg-[#002B5B] text-white font-bold px-2.5 py-1.5 rounded text-xs tracking-wider uppercase shadow-xs">
              DMI Patna
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-base sm:text-lg font-bold tracking-tight text-[#002B5B] hover:underline">
                  Placement Intelligence
                </h1>
                <span className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-[#002B5B]/10 text-[#002B5B] border border-[#002B5B]/20 rounded">
                  Decision Support System
                </span>
              </div>
              <p className="text-[11px] text-gray-500">
                Development Management Institute — Institutional Placement Cell
              </p>
            </div>
          </div>

          {/* Right Selectors & Controls */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-2.5 text-xs">
            
            {/* Front Portal Button */}
            <button
              onClick={onHomeClick}
              className="bg-gray-100 hover:bg-gray-200 text-[#002B5B] px-2.5 py-1 rounded border border-gray-300 font-bold text-[11px] cursor-pointer"
            >
              Front Portal
            </button>

            {/* Auth / Login Status Button */}
            <button
              onClick={onOpenAuthModal}
              className={`px-2.5 py-1 rounded border text-[11px] font-bold flex items-center space-x-1 cursor-pointer transition-colors ${
                isLoggedIn
                  ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
                  : 'bg-[#002B5B] text-white border-[#002B5B] hover:bg-[#001D3D]'
              }`}
            >
              <UserCheck className="w-3.5 h-3.5" />
              <span>{isLoggedIn ? (userName || 'Logged In') : 'Sign In / OTP'}</span>
            </button>

            {/* Academic Year Selector */}
            <div className="flex items-center space-x-1.5 bg-gray-50 px-2.5 py-1 rounded border border-gray-200">
              <span className="text-gray-500 text-[10px] uppercase font-bold">AY:</span>
              <select
                value={filters.academicYear}
                onChange={(e) => setFilters(prev => ({ ...prev, academicYear: e.target.value }))}
                className="bg-transparent text-[#2D3436] font-semibold focus:outline-none cursor-pointer"
              >
                <option value="All">All Years</option>
                {ACADEMIC_YEARS.map(ay => (
                  <option key={ay} value={ay}>{ay}</option>
                ))}
              </select>
            </div>

            {/* Batch Selector */}
            <div className="flex items-center space-x-1.5 bg-gray-50 px-2.5 py-1 rounded border border-gray-200">
              <span className="text-gray-500 text-[10px] uppercase font-bold">Batch:</span>
              <select
                value={filters.batch}
                onChange={(e) => setFilters(prev => ({ ...prev, batch: e.target.value }))}
                className="bg-transparent text-[#2D3436] font-semibold focus:outline-none cursor-pointer"
              >
                <option value="All">All Batches</option>
                {BATCHES.map(b => (
                  <option key={b} value={b}>{b}</option>
                ))}
              </select>
            </div>

            {/* Role-Based Access Switcher */}
            <div className="flex items-center space-x-1 bg-gray-50 px-2 py-1 rounded border border-gray-200">
              <UserCheck className="w-3.5 h-3.5 text-[#002B5B]" />
              <select
                value={userRole}
                onChange={(e) => setUserRole(e.target.value as UserRole)}
                className="bg-transparent text-[#2D3436] font-semibold text-xs focus:outline-none cursor-pointer"
              >
                <option value="placement_cell">Placement Cell</option>
                <option value="academic_team">Academic Team</option>
                <option value="leadership">Leadership</option>
                <option value="student">Restricted Student View</option>
              </select>
            </div>

            {/* Ask AI Button */}
            <button
              onClick={onOpenAskData}
              className="flex items-center space-x-1.5 bg-[#4C7031] hover:bg-[#3c5927] text-white font-medium px-3 py-1.5 rounded transition-colors shadow-xs cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-100" />
              <span className="hidden sm:inline">Ask Data AI</span>
            </button>

            {/* Export PDF Button */}
            <button
              onClick={onExportPDF}
              className="flex items-center space-x-1.5 bg-[#002B5B] hover:bg-[#001f42] text-white font-medium px-3 py-1.5 rounded transition-colors shadow-xs cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Export Report</span>
            </button>

          </div>
        </div>
      </div>
    </header>
  );
};
