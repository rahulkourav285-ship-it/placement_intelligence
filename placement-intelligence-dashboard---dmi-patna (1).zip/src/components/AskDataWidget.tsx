import React, { useState } from 'react';
import { Sparkles, Send, X, HelpCircle, Bot, Loader2, BookOpen } from 'lucide-react';

interface AskDataWidgetProps {
  isOpen: boolean;
  onClose: () => void;
  contextSummary: any;
}

export const AskDataWidget: React.FC<AskDataWidgetProps> = ({
  isOpen,
  onClose,
  contextSummary
}) => {
  const [question, setQuestion] = useState('');
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState<string | null>(null);
  const [source, setSource] = useState<string | null>(null);

  const sampleQuestions = [
    'Why did interview conversion decline?',
    'Which skills have the largest employer-student gap?',
    'Which recruiters should DMI prioritize?',
    'Which development sectors are growing fastest?',
    'What are the top interview rejection reasons?',
    'Which electives align best with employer demand?'
  ];

  const handleSend = async (qToSend?: string) => {
    const q = qToSend || question;
    if (!q.trim()) return;

    setLoading(true);
    setResponse(null);

    try {
      const res = await fetch('/api/ask-data', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: q, contextSummary })
      });

      const data = await res.json();
      setResponse(data.answer || 'No analytics insight returned.');
      setSource(data.source || 'Intelligence Engine');
    } catch (err) {
      console.error('Ask Data API Error:', err);
      setResponse('Failed to fetch analytics response. Please try again.');
      setSource('Error');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl overflow-hidden border border-slate-200 flex flex-col max-h-[85vh]">
        
        {/* Header */}
        <div className="bg-[#0f2942] text-white px-5 py-4 flex items-center justify-between border-b border-slate-700">
          <div className="flex items-center space-x-2.5">
            <div className="p-1.5 bg-indigo-600 rounded text-white">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-white">Ask the Placement Data</h2>
              <p className="text-xs text-slate-300">
                Decision Support Query Engine for DMI Patna
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-300 hover:text-white rounded hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 flex-1 overflow-y-auto space-y-4 text-xs">
          
          {/* Sample Prompts */}
          {!response && !loading && (
            <div>
              <p className="font-semibold text-slate-700 mb-2 flex items-center space-x-1">
                <HelpCircle className="w-3.5 h-3.5 text-indigo-600" />
                <span>Suggested Placement Intelligence Queries:</span>
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {sampleQuestions.map((q, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setQuestion(q);
                      handleSend(q);
                    }}
                    className="text-left px-3 py-2 bg-slate-50 hover:bg-indigo-50/70 border border-slate-200 hover:border-indigo-200 rounded text-slate-700 font-medium transition-colors cursor-pointer"
                  >
                    "{q}"
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Loading Indicator */}
          {loading && (
            <div className="flex flex-col items-center justify-center py-8 space-y-3">
              <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
              <p className="text-slate-600 font-medium">Analyzing DMI Placement Dataset...</p>
            </div>
          )}

          {/* Answer Display */}
          {response && !loading && (
            <div className="bg-slate-50 rounded-lg p-4 border border-slate-200 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                <span className="font-semibold text-slate-800 flex items-center space-x-1.5">
                  <Bot className="w-4 h-4 text-indigo-600" />
                  <span>Placement Cell Insight</span>
                </span>
                <span className="text-[10px] bg-indigo-100 text-indigo-800 font-bold px-2 py-0.5 rounded">
                  Source: {source}
                </span>
              </div>
              <div className="text-slate-700 leading-relaxed space-y-2 whitespace-pre-line text-xs font-sans">
                {response}
              </div>
            </div>
          )}

        </div>

        {/* Query Input Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center space-x-2"
          >
            <input
              type="text"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="e.g., Why did interview conversion decline?"
              className="flex-1 bg-white border border-slate-300 rounded px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
            <button
              type="submit"
              disabled={loading || !question.trim()}
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium px-4 py-2 rounded flex items-center space-x-1 text-xs disabled:opacity-50 transition-colors cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Ask</span>
            </button>
          </form>
        </div>

      </div>
    </div>
  );
};
