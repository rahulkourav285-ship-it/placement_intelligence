import React from 'react';
import { LayoutDashboard, LogIn, Compass, TrendingUp, Users, Target, ShieldCheck, ArrowRight, Building2, BookOpen, Award, CheckCircle2, Phone, Mail } from 'lucide-react';
import { GaugeChart } from './common/GaugeChart';

interface LandingPortalProps {
  onExploreClick: () => void;
  onOpenAuthModal: () => void;
  isLoggedIn: boolean;
  userName?: string;
  userRole?: string;
}

export const LandingPortal: React.FC<LandingPortalProps> = ({
  onExploreClick,
  onOpenAuthModal,
  isLoggedIn,
  userName,
  userRole
}) => {
  return (
    <div className="min-h-screen bg-[#F1F3F5] text-[#2D3436] flex flex-col font-sans selection:bg-[#002B5B]/10 selection:text-[#002B5B]">
      
      {/* Front Hero Header Bar */}
      <header className="bg-[#002B5B] text-white border-b border-[#002B5B] shadow-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          
          {/* Brand Logo & Institution */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded bg-white text-[#002B5B] font-black text-xl flex items-center justify-center shadow-xs border border-white/20">
              DMI
            </div>
            <div>
              <h1 className="text-sm sm:text-base font-bold tracking-tight text-white leading-tight">
                Development Management Institute (DMI), Patna
              </h1>
              <p className="text-[10px] text-emerald-300 font-semibold tracking-wider uppercase">
                Placement Intelligence & Decision Support Portal
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-3">
            {isLoggedIn ? (
              <div className="flex items-center space-x-2 bg-white/10 px-3 py-1.5 rounded border border-white/20 text-xs">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span className="font-bold">{userName}</span>
                <span className="text-[10px] opacity-75 capitalize">({userRole?.replace('_', ' ')})</span>
              </div>
            ) : (
              <button
                onClick={onOpenAuthModal}
                className="bg-white/10 hover:bg-white/20 text-white border border-white/30 px-3.5 py-1.5 rounded text-xs font-bold flex items-center space-x-1.5 transition-colors cursor-pointer"
              >
                <LogIn className="w-4 h-4 text-emerald-300" />
                <span>Sign In / OTP Login</span>
              </button>
            )}

            <button
              onClick={onExploreClick}
              className="bg-[#4C7031] hover:bg-[#385423] text-white font-bold px-4 py-2 rounded text-xs shadow-xs flex items-center space-x-1.5 transition-all cursor-pointer transform hover:scale-102"
            >
              <span>Explore Dashboard</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </div>
      </header>

      {/* Hero Banner */}
      <section className="bg-gradient-to-b from-[#002B5B] to-[#001D3D] text-white py-12 px-4 sm:px-6 lg:px-8 border-b border-gray-200">
        <div className="max-w-5xl mx-auto text-center space-y-6">
          
          <div className="inline-flex items-center space-x-2 bg-white/10 border border-white/20 px-3 py-1 rounded-full text-xs font-mono text-emerald-300">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Official Institutional Decision Support System — PDM 12 (2025–26)</span>
          </div>

          <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight leading-tight">
            Comprehensive Placement Intelligence & Skill Gap Diagnostic Platform
          </h2>

          <p className="text-xs sm:text-sm text-gray-200 max-w-3xl mx-auto leading-relaxed">
            Designed for DMI Patna placement officers, academic chairs, and institutional leadership to analyze candidate readiness, employer demand curves, alumni career trajectories, and curriculum alignment across Development Management domains.
          </p>

          {/* Primary CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <button
              onClick={onExploreClick}
              className="w-full sm:w-auto bg-[#4C7031] hover:bg-[#385423] text-white font-black px-8 py-3.5 rounded text-sm shadow-md flex items-center justify-center space-x-2 transition-all cursor-pointer transform hover:scale-102"
            >
              <LayoutDashboard className="w-5 h-5" />
              <span>CLICK TO EXPLORE DASHBOARD</span>
              <ArrowRight className="w-5 h-5 ml-1" />
            </button>

            {!isLoggedIn && (
              <button
                onClick={onOpenAuthModal}
                className="w-full sm:w-auto bg-white/10 hover:bg-white/20 border border-white/30 text-white font-bold px-6 py-3.5 rounded text-sm shadow-xs flex items-center justify-center space-x-2 transition-colors cursor-pointer"
              >
                <LogIn className="w-4 h-4 text-emerald-300" />
                <span>Sign Up / Login with Mobile OTP or Gmail</span>
              </button>
            )}
          </div>

        </div>
      </section>

      {/* Key Metrics & Gauge Preview Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 w-full space-y-6">
        
        <div className="text-center space-y-1">
          <h3 className="text-base font-bold text-[#002B5B] uppercase tracking-wider">
            Placement Performance Gauge Diagnostic Indicators
          </h3>
          <p className="text-xs text-gray-500">
            Real-time percentage gauges tracking institutional effectiveness for Batch PDM 12
          </p>
        </div>

        {/* Gauge Charts Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <GaugeChart
            title="Placement Rate"
            subtitle="Current Batch Placed"
            value={94}
            unit="%"
            color="#4C7031"
          />
          <GaugeChart
            title="Interview Conversion"
            subtitle="Offers per Shortlist"
            value={32}
            unit="%"
            color="#002B5B"
          />
          <GaugeChart
            title="Repeat Recruiter Loyalty"
            subtitle="Recurring Partner Orgs"
            value={78}
            unit="%"
            color="#4C7031"
          />
          <GaugeChart
            title="MIS Data Quality"
            subtitle="Validated Records"
            value={87}
            unit="%"
            color="#002B5B"
          />
        </div>

        {/* Feature Highlights Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-6">
          
          <div className="bg-white p-5 rounded border border-gray-200 shadow-xs space-y-3 hover:border-[#002B5B]/40 transition-all">
            <div className="w-9 h-9 rounded bg-[#002B5B]/10 text-[#002B5B] flex items-center justify-center font-bold">
              <Compass className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-[#002B5B]">Geographical Alumni Map Tracker</h4>
            <p className="text-xs text-gray-600 leading-relaxed">
              Track 480+ alumni serving in senior leadership, M&E, and project lead roles across Bihar state districts and key national hubs. Apply global location filters directly from the interactive map.
            </p>
          </div>

          <div className="bg-white p-5 rounded border border-gray-200 shadow-xs space-y-3 hover:border-[#002B5B]/40 transition-all">
            <div className="w-9 h-9 rounded bg-[#4C7031]/10 text-[#4C7031] flex items-center justify-center font-bold">
              <Target className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-[#002B5B]">Skill Gap & Priority Indexing</h4>
            <p className="text-xs text-gray-600 leading-relaxed">
              Decompose employer demand against student proficiency across Excel, Power BI, M&E, and Case Analysis competencies to launch targeted pre-placement bootcamps.
            </p>
          </div>

          <div className="bg-white p-5 rounded border border-gray-200 shadow-xs space-y-3 hover:border-[#002B5B]/40 transition-all">
            <div className="w-9 h-9 rounded bg-indigo-100 text-indigo-900 flex items-center justify-center font-bold">
              <Building2 className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-[#002B5B]">Recruiter Relationship Matrix</h4>
            <p className="text-xs text-gray-600 leading-relaxed">
              Categorize key recruiters (JEEViKA, COMFED, CARE India, PRADAN, UNICEF) into Strategic Partners, Growth Potential, and Re-engagement quadrants to maximize hiring yield.
            </p>
          </div>

        </div>

      </section>

      {/* Front Footer */}
      <footer className="bg-white border-t border-gray-200 mt-auto py-6 px-4 text-center text-xs text-gray-500 space-y-2">
        <p className="font-bold text-[#002B5B]">
          Development Management Institute (DMI), Patna — Placement Intelligence Portal
        </p>
        <p className="text-[11px] text-gray-400">
          Udyog Bhawan, East Gandhi Maidan, Patna, Bihar 800004 | Email: placement@dmi.ac.in
        </p>
      </footer>

    </div>
  );
};
