import React, { useState, useMemo } from 'react';
import { Header } from './components/Header';
import { Sidebar, NavTab } from './components/Sidebar';
import { FilterBar } from './components/FilterBar';
import { AskDataWidget } from './components/AskDataWidget';
import { LandingPortal } from './components/LandingPortal';
import { AuthModal } from './components/common/AuthModal';

// Views
import { ExecutiveOverviewView } from './components/views/ExecutiveOverviewView';
import { PlacementDiagnosticsView } from './components/views/PlacementDiagnosticsView';
import { SkillGapView } from './components/views/SkillGapView';
import { RecruiterIntelligenceView } from './components/views/RecruiterIntelligenceView';
import { SectorTrendsView } from './components/views/SectorTrendsView';
import { InterviewAnalyticsView } from './components/views/InterviewAnalyticsView';
import { CurriculumAlignmentView } from './components/views/CurriculumAlignmentView';
import { ElectivesPathwaysView } from './components/views/ElectivesPathwaysView';
import { AlumniIntelligenceView } from './components/views/AlumniIntelligenceView';
import { StudentEmployabilityView } from './components/views/StudentEmployabilityView';
import { RecommendationsView } from './components/views/RecommendationsView';
import { DataQualityView } from './components/views/DataQualityView';

import { FilterState, UserRole, UserAuth } from './types';
import { computeFilteredData } from './analyticsEngine';
import { Menu, ShieldAlert, FileText, Printer } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('executive');
  const [userRole, setUserRole] = useState<UserRole>('placement_cell');
  const [isOpenMobileSidebar, setIsOpenMobileSidebar] = useState(false);
  const [isAskDataOpen, setIsAskDataOpen] = useState(false);
  const [isLandingPage, setIsLandingPage] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  const [userAuth, setUserAuth] = useState<UserAuth>({
    isLoggedIn: true,
    authMethod: 'mobile',
    phoneNumber: '9876543210',
    name: 'Rahul Kourav',
    role: 'placement_cell'
  });

  const [filters, setFilters] = useState<FilterState>({
    academicYear: 'All',
    batch: 'All',
    sector: 'All',
    recruiter: 'All',
    jobFunction: 'All',
    skillCategory: 'All',
    placementStatus: 'All',
    stateRegion: 'All'
  });

  // Calculate reactive filtered dataset
  const filteredData = useMemo(() => {
    return computeFilteredData(filters);
  }, [filters]);

  // Export PDF Handler
  const handleExportPDF = () => {
    window.print();
  };

  const handleSelectRegion = (region: string) => {
    setFilters(prev => ({ ...prev, stateRegion: region }));
    setActiveTab('alumni_intelligence');
  };

  if (isLandingPage) {
    return (
      <>
        <LandingPortal
          onExploreClick={() => setIsLandingPage(false)}
          onOpenAuthModal={() => setIsAuthModalOpen(true)}
          isLoggedIn={userAuth.isLoggedIn}
          userName={userAuth.name}
          userRole={userAuth.role}
        />
        <AuthModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
          onLoginSuccess={(user) => {
            setUserAuth(user);
            setUserRole(user.role);
          }}
          currentRole={userRole}
        />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-[#F1F3F5] text-[#2D3436] flex flex-col font-sans selection:bg-[#002B5B]/10 selection:text-[#002B5B]">
      
      {/* Top Header */}
      <Header
        filters={filters}
        setFilters={setFilters}
        userRole={userRole}
        setUserRole={setUserRole}
        onExportPDF={handleExportPDF}
        onOpenAskData={() => setIsAskDataOpen(true)}
        onHomeClick={() => setIsLandingPage(true)}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        isLoggedIn={userAuth.isLoggedIn}
        userName={userAuth.name}
      />

      {/* Secondary Filter Bar */}
      <FilterBar filters={filters} setFilters={setFilters} />

      {/* Main Layout Container */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        
        {/* Sidebar */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          isOpenMobile={isOpenMobileSidebar}
          setIsOpenMobile={setIsOpenMobileSidebar}
        />

        {/* Main Content Area */}
        <main className="flex-1 p-4 sm:p-6 overflow-x-hidden min-w-0">
          
          {/* Mobile Navigation Toggle Bar */}
          <div className="lg:hidden mb-4 flex items-center justify-between bg-white p-3 rounded border border-gray-200 shadow-xs">
            <button
              onClick={() => setIsOpenMobileSidebar(true)}
              className="flex items-center space-x-2 text-xs font-bold text-[#002B5B] bg-gray-100 hover:bg-gray-200 px-3 py-1.5 rounded transition-colors cursor-pointer"
            >
              <Menu className="w-4 h-4 text-[#002B5B]" />
              <span>Navigation Menu</span>
            </button>
            <span className="text-xs font-bold text-[#002B5B] capitalize">
              {activeTab.replace('_', ' ')}
            </span>
          </div>

          {/* Role Access Restriction Banner for Student View */}
          {userRole === 'student' && (
            <div className="mb-4 bg-amber-50 border border-amber-200 text-amber-900 p-3 rounded text-xs flex items-center space-x-2">
              <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0" />
              <span>
                <strong>Restricted Student View Active:</strong> Individual recruiter contact credentials and student salary rankings are masked for privacy compliance.
              </span>
            </div>
          )}

          {/* Dynamic Navigation View Routing */}
          <div className="print:p-0">
            {activeTab === 'executive' && (
              <ExecutiveOverviewView
                summary={filteredData.executive_summary}
                onNavigateTab={(tab) => setActiveTab(tab)}
              />
            )}

            {activeTab === 'placement_diagnostics' && (
              <PlacementDiagnosticsView
                students={filteredData.students}
                recruiters={filteredData.recruiters}
              />
            )}

            {(activeTab === 'skill_gap' || activeTab === 'job_demand') && (
              <SkillGapView skills={filteredData.skill_metrics} />
            )}

            {activeTab === 'interview_analytics' && (
              <InterviewAnalyticsView />
            )}

            {activeTab === 'student_employability' && (
              <StudentEmployabilityView students={filteredData.students} />
            )}

            {(activeTab === 'recruiter_intelligence' || activeTab === 'recruiter_map') && (
              <RecruiterIntelligenceView recruiters={filteredData.recruiters} />
            )}

            {activeTab === 'sector_trends' && (
              <SectorTrendsView sectorTrends={filteredData.sector_trends} />
            )}

            {(activeTab === 'curriculum_alignment' || activeTab === 'internship_alignment') && (
              <CurriculumAlignmentView courseAlignments={filteredData.course_alignments} />
            )}

            {activeTab === 'electives_certifications' && (
              <ElectivesPathwaysView />
            )}

            {activeTab === 'alumni_intelligence' && (
              <AlumniIntelligenceView
                data={filteredData}
                filters={filters}
                onSelectRegion={handleSelectRegion}
              />
            )}

            {activeTab === 'recommendations' && (
              <RecommendationsView />
            )}

            {activeTab === 'data_quality' && (
              <DataQualityView />
            )}
          </div>

        </main>
      </div>

      {/* Auth Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLoginSuccess={(user) => {
          setUserAuth(user);
          setUserRole(user.role);
        }}
        currentRole={userRole}
      />

      {/* Ask the Placement Data AI Modal */}
      <AskDataWidget
        isOpen={isAskDataOpen}
        onClose={() => setIsAskDataOpen(false)}
        contextSummary={filteredData.executive_summary.kpis}
      />

      {/* Print / Report Footer for PDF Exporting */}
      <footer className="h-12 bg-white border-t border-gray-200 px-6 sm:px-8 flex flex-col sm:flex-row items-center justify-between text-[10px] text-gray-500 mt-auto print:hidden gap-2 py-2">
        <p>Development Management Institute (DMI), Patna | Placement Cell Decision Support System</p>
        <div className="flex items-center space-x-3">
          <p><strong>Data Note:</strong> Dashboard analytics are illustrative for institutional evaluation.</p>
          <button
            onClick={handleExportPDF}
            className="text-[#002B5B] hover:text-[#4C7031] font-bold flex items-center space-x-1 cursor-pointer"
          >
            <Printer className="w-3 h-3" />
            <span>Print Report</span>
          </button>
        </div>
      </footer>

    </div>
  );
}
