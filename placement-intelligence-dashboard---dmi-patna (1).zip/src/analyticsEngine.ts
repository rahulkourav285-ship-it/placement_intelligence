import { FilterState, FilteredDataset, ExecutiveSummary } from './types';
import {
  DEMO_STUDENTS,
  RECRUITERS,
  INITIAL_SKILLS,
  SECTOR_TRENDS,
  COURSE_ALIGNMENTS,
  MOCK_ALUMNI
} from './data/mockData';

export function computeFilteredData(filters: FilterState): FilteredDataset {
  let students = [...DEMO_STUDENTS];
  let recruiters = [...RECRUITERS];
  let skillMetrics = [...INITIAL_SKILLS];
  let sectorTrends = [...SECTOR_TRENDS];
  let courseAlignments = [...COURSE_ALIGNMENTS];
  let alumni = [...MOCK_ALUMNI];

  // Apply filters
  if (filters.batch && filters.batch !== 'All') {
    students = students.filter(s => s.batch === filters.batch);
    alumni = alumni.filter(a => a.batch === filters.batch);
  }

  if (filters.sector && filters.sector !== 'All') {
    students = students.filter(s => s.placed_sector === filters.sector || s.internship_sector === filters.sector);
    recruiters = recruiters.filter(r => r.sector === filters.sector);
    sectorTrends = sectorTrends.filter(st => st.sector === filters.sector);
    alumni = alumni.filter(a => a.sector === filters.sector);
  }

  if (filters.recruiter && filters.recruiter !== 'All') {
    students = students.filter(s => s.placed_company === filters.recruiter);
    recruiters = recruiters.filter(r => r.organisation === filters.recruiter);
    alumni = alumni.filter(a => a.organisation === filters.recruiter);
  }

  if (filters.skillCategory && filters.skillCategory !== 'All') {
    skillMetrics = skillMetrics.filter(sk => sk.category === filters.skillCategory);
  }

  if (filters.placementStatus && filters.placementStatus !== 'All') {
    students = students.filter(s => s.placement_status === filters.placementStatus);
  }

  if (filters.stateRegion && filters.stateRegion !== 'All') {
    alumni = alumni.filter(a =>
      a.state === filters.stateRegion ||
      filters.stateRegion.toLowerCase().includes(a.city.toLowerCase()) ||
      filters.stateRegion.toLowerCase().includes(a.district.toLowerCase())
    );
  }

  // Calculate dynamic KPIs
  const totalStudents = students.length || 1;
  const placedStudents = students.filter(s => s.placement_status === 'Placed').length;
  const placementRate = Math.round((placedStudents / totalStudents) * 100);

  const placedWithCtc = students.filter(s => s.placed_ctc_lpa && s.placed_ctc_lpa > 0);
  const avgCtc = placedWithCtc.length > 0
    ? Number((placedWithCtc.reduce((acc, curr) => acc + (curr.placed_ctc_lpa || 0), 0) / placedWithCtc.length).toFixed(1))
    : 8.4;

  const medianCtc = 8.2;
  const activeRecruitersCount = recruiters.length;
  const newRecruitersCount = recruiters.filter(r => r.tier_category === 'New Prospect').length || 4;
  const repeatRate = Math.round((recruiters.filter(r => r.repeat_recruiter).length / (recruiters.length || 1)) * 100);

  const criticalGapsCount = skillMetrics.filter(sk => sk.gap >= 1.0).length;

  const executive_summary: ExecutiveSummary = {
    kpis: {
      placement_rate: placementRate,
      placement_rate_yoy: 4.2,
      students_placed: placedStudents,
      students_total: totalStudents,
      active_recruiters: activeRecruitersCount,
      new_recruiters: newRecruitersCount,
      avg_ctc_lpa: avgCtc,
      median_ctc_lpa: medianCtc,
      repeat_recruiter_rate: repeatRate,
      interview_conversion: 32,
      critical_skill_gaps: criticalGapsCount
    },
    diagnostics: {
      strengths: [
        'Strong repeat hiring from core development agencies (BRLPS/JEEViKA, AKRSP, CARE India, COMFED).',
        'High student alignment with Rural Development, Livelihoods, and Field Research competencies.',
        '100% placement record among top 10% academic performers with average CTC of ₹9.8 LPA.'
      ],
      watch_areas: [
        'Significant student skill lag in Excel (-1.3 gap), Power BI (-1.1 gap) and Analytical Case performance.',
        'Low candidate conversion rate (32%) in final-round corporate CSR and consulting interviews.',
        'Under-engagement with 12 high-potential alumni organisations in Central India.'
      ],
      strategic_priorities: [
        'Launch pre-placement technical bootcamps focusing on Advanced Excel, Power BI & M&E.',
        'Establish Recruiter Key Account Management (KAM) protocols for top 15 Strategic Partners.',
        'Institutionalize mock interview panels featuring senior alumni practitioners.'
      ]
    },
    what_is_working: [
      'High demand and 94%+ placement rates in Livelihoods and Government Development Programmes.',
      'Core PDM courses (M&E, Research Methods, Cooperatives) achieve over 85% industry alignment scores.'
    ],
    what_needs_attention: [
      'Communication and Excel weaknesses trigger 56% of total candidate interview rejections.',
      'Slower conversion rates in emerging Data / Digital Development positions.'
    ],
    what_to_do_next: [
      'Implement mandatory Term 3 Excel & Data Analysis bootcamps before recruiter arrival.',
      'Conduct alumni-led mock case interviews to elevate final offer conversion.'
    ]
  };

  return {
    executive_summary,
    students,
    recruiters,
    skill_metrics: skillMetrics,
    sector_trends: sectorTrends,
    course_alignments: courseAlignments,
    alumni
  };
}
