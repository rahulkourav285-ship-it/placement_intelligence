/**
 * Placement Intelligence Dashboard - DMI Patna
 * Data types & Interfaces
 */

export type UserRole = 'placement_cell' | 'academic_team' | 'leadership' | 'student';

export interface FilterState {
  academicYear: string;
  batch: string;
  sector: string;
  recruiter: string;
  jobFunction: string;
  skillCategory: string;
  placementStatus: string;
  stateRegion: string;
}

export interface UserAuth {
  isLoggedIn: boolean;
  authMethod: 'mobile' | 'google' | 'guest';
  phoneNumber?: string;
  email?: string;
  name: string;
  role: UserRole;
  avatarUrl?: string;
}

export interface Student {
  student_id: string;
  name: string;
  batch: string;
  academic_year: string;
  gender: 'Female' | 'Male' | 'Other';
  academic_score: number; // Percentage or CGPA scale out of 10
  academic_band: 'Top 10%' | 'Upper 25%' | 'Mid Tier' | 'Needs Support';
  internship_sector: string;
  internship_org: string;
  electives: string[];
  certifications: string[];
  skills: Record<string, number>; // skill_id -> proficiency (1-5)
  placement_status: 'Placed' | 'In Process' | 'Seeking Offers';
  placed_company?: string;
  placed_sector?: string;
  placed_ctc_lpa?: number;
  placed_role?: string;
  interview_attempts: number;
  shortlists_count: number;
  offers_count: number;
  rejection_reasons: string[];
  employability_index: number; // 0-100
}

export interface Recruiter {
  recruiter_id: string;
  organisation: string;
  sector: string;
  relationship_years: number;
  hiring_cycles: number;
  students_hired: number;
  positions_offered: number;
  applications_received: number;
  interviews_conducted: number;
  offers_made: number;
  interview_conversion: number; // percentage
  avg_ctc_lpa: number;
  max_ctc_lpa: number;
  repeat_recruiter: boolean;
  internship_engagement: 'High' | 'Medium' | 'Low' | 'None';
  alumni_presence: number; // count of alumni working there
  relationship_score: number; // 0-100
  tier_category: 'Strategic Partner' | 'High Potential' | 'Maintain' | 'Re-engage' | 'New Prospect';
  matrix_quadrant: 'Strategic Partners' | 'Growth Opportunities' | 'Maintain' | 'Re-engage';
  contact_level: 'Executive' | 'HR Head' | 'Alumni Lead' | 'General HR';
  primary_roles: string[];
  key_skills_sought: string[];
}

export interface SkillMetric {
  skill_id: string;
  skill_name: string;
  category: 'Technical' | 'Domain & Development' | 'Analytics & Tools' | 'Soft & Management';
  employer_demand: number; // 1-5 scale
  student_proficiency: number; // 1-5 scale
  gap: number; // employer_demand - student_proficiency
  priority_index: number; // gap * employer_demand
  priority_tier: 'High Priority' | 'Medium Priority' | 'Low Priority';
  batch_proficiencies: Record<string, number>; // batch -> average score
}

export interface SectorTrend {
  sector: string;
  hiring_demand_count: number;
  student_interest_pct: number;
  avg_ctc_lpa: number;
  max_ctc_lpa: number;
  yoy_growth_pct: number;
  repeat_hiring_rate: number;
  top_roles: string[];
  key_skills: string[];
  attractiveness_diagnostic: string;
  yearly_hiring: { year: string; hires: number }[];
}

export interface InterviewRecord {
  record_id: string;
  student_id: string;
  recruiter_id: string;
  organisation: string;
  sector: string;
  round: 'Aptitude / Screening' | 'Case Analysis' | 'Technical Round' | 'Personal Interview' | 'HR Round';
  result: 'Selected' | 'Rejected' | 'Shortlisted';
  rejection_reason?: 'Communication' | 'Excel / Technical Skills' | 'Domain Knowledge' | 'Analytical Ability' | 'Aptitude' | 'Case Interview' | 'Lack of Relevant Experience' | 'Role Fit' | 'Salary / Location Preference';
  communication_score: number; // 1-5
  technical_score: number;
  domain_score: number;
  analytical_score: number;
  case_score: number;
}

export interface CourseAlignment {
  course_id: string;
  course_name: string;
  category: string;
  skills_covered: string[];
  skill_coverage_score: number; // 1-5
  employer_demand_score: number; // 1-5
  student_proficiency_avg: number; // 1-5
  alignment_score: number; // percentage
  enrolled_students: number;
  placement_rate_pct: number;
  industry_relevance_notes: string;
}

export interface AlumniRecord {
  alumni_id: string;
  code_name: string; // Anonymized e.g. "Alumni A01"
  batch: string;
  passout_year: number;
  organisation: string;
  sector: string;
  designation: string;
  role_level: 'Leadership / CXO' | 'Senior Manager' | 'Project Head' | 'Senior Consultant' | 'Mid-Level Specialist';
  recruiter_potential: 'High' | 'Medium' | 'Low';
  engagement_status: 'Active Partner' | 'Guest Speaker' | 'Potential Referral' | 'Unmapped';
  state: string;
  district: string;
  city: string;
  students_hired_under_lead: number;
  latitude?: number;
  longitude?: number;
}

export interface RecommendationItem {
  id: string;
  number: string;
  title: string;
  evidence: string;
  action: string;
  expected_outcome: string;
  priority: 'HIGH' | 'MEDIUM-HIGH' | 'MEDIUM';
  owner: string;
  timeline: string;
  status: 'Implemented' | 'In Progress' | 'Under Review';
}

export interface DataQualityIssue {
  id: string;
  category: 'Student Data' | 'Recruiter Data' | 'Interview Data' | 'Alumni Data';
  issue: string;
  affected_records: number;
  impact_level: 'High' | 'Medium' | 'Low';
  action_required: string;
}

export interface FilteredDataset {
  executive_summary: ExecutiveSummary;
  students: Student[];
  recruiters: Recruiter[];
  skill_metrics: SkillMetric[];
  sector_trends: SectorTrend[];
  course_alignments: CourseAlignment[];
  alumni: AlumniRecord[];
}

export interface ExecutiveSummary {
  kpis: {
    placement_rate: number;
    placement_rate_yoy: number;
    students_placed: number;
    students_total: number;
    active_recruiters: number;
    new_recruiters: number;
    avg_ctc_lpa: number;
    median_ctc_lpa: number;
    repeat_recruiter_rate: number;
    interview_conversion: number;
    critical_skill_gaps: number;
  };
  diagnostics: {
    strengths: string[];
    watch_areas: string[];
    strategic_priorities: string[];
  };
  what_is_working: string[];
  what_needs_attention: string[];
  what_to_do_next: string[];
}
