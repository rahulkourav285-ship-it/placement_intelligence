import {
  FilterState,
  Student,
  Recruiter,
  SkillMetric,
  SectorTrend,
  InterviewRecord,
  ExecutiveSummary
} from '../types';

import {
  DEMO_STUDENTS,
  RECRUITERS,
  INITIAL_SKILLS,
  SECTOR_TRENDS,
  INTERVIEW_REJECTION_DATA,
  COURSE_ALIGNMENTS,
  ALUMNI_RECORDS,
  STRATEGIC_RECOMMENDATIONS,
  DATA_QUALITY_ISSUES
} from './mockData';

export function computeFilteredData(filters: FilterState) {
  // Filter Students
  let students = DEMO_STUDENTS.filter(s => {
    if (filters.batch !== 'All' && s.batch !== filters.batch) return false;
    if (filters.academicYear !== 'All' && s.academic_year !== filters.academicYear) return false;
    if (filters.sector !== 'All' && s.placed_sector !== filters.sector && s.internship_sector !== filters.sector) return false;
    if (filters.recruiter !== 'All' && s.placed_company !== filters.recruiter) return false;
    if (filters.placementStatus !== 'All' && s.placement_status !== filters.placementStatus) return false;
    return true;
  });

  // Filter Recruiters
  let recruiters = RECRUITERS.filter(r => {
    if (filters.sector !== 'All' && r.sector !== filters.sector) return false;
    if (filters.recruiter !== 'All' && r.organisation !== filters.recruiter) return false;
    return true;
  });

  // Filter Skills
  let skills = INITIAL_SKILLS.filter(sk => {
    if (filters.skillCategory !== 'All' && sk.category !== filters.skillCategory) return false;
    return true;
  });

  // KPI Calculations
  const studentsTotal = students.length || 1; // avoid divide by zero
  const studentsPlaced = students.filter(s => s.placement_status === 'Placed').length;
  const placementRate = Math.round((studentsPlaced / studentsTotal) * 100);

  const activeRecruiters = recruiters.length;
  const newRecruiters = recruiters.filter(r => !r.repeat_recruiter).length;
  const repeatRecruitersCount = recruiters.filter(r => r.repeat_recruiter).length;
  const repeatRecruiterRate = activeRecruiters > 0 ? Math.round((repeatRecruitersCount / activeRecruiters) * 100) : 0;

  // CTC Calculations
  const placedStudentsWithCTC = students.filter(s => s.placed_ctc_lpa !== undefined && s.placed_ctc_lpa > 0);
  const avgCTC = placedStudentsWithCTC.length > 0
    ? Number((placedStudentsWithCTC.reduce((acc, curr) => acc + (curr.placed_ctc_lpa || 0), 0) / placedStudentsWithCTC.length).toFixed(1))
    : 8.4;

  const sortedCTCs = placedStudentsWithCTC.map(s => s.placed_ctc_lpa || 0).sort((a, b) => a - b);
  const medianCTC = sortedCTCs.length > 0 ? sortedCTCs[Math.floor(sortedCTCs.length / 2)] : 8.2;

  // Interview Conversion
  const totalInterviewsConducted = recruiters.reduce((acc, curr) => acc + curr.interviews_conducted, 0);
  const totalOffersMade = recruiters.reduce((acc, curr) => acc + curr.offers_made, 0);
  const interviewConversion = totalInterviewsConducted > 0 ? Math.round((totalOffersMade / totalInterviewsConducted) * 100) : 32;

  // Critical Skill Gaps
  const criticalSkillGaps = skills.filter(sk => sk.gap >= 1.0).length;

  // Strengths, Watch Areas, Priorities (Dynamic based on filter)
  const strengths = [
    `Strong development-sector recruiter base with ${repeatRecruiterRate}% repeat recruitment rate.`,
    'High employer demand for field research, livelihoods, and project management capabilities.',
    'Consistent experiential-learning conversion from Management Internships to final offers.'
  ];

  const watchAreas = [
    `Analytical skills and Excel proficiency show an average gap of -1.3 points across ${filters.batch !== 'All' ? filters.batch : 'PDM 12'}.`,
    'Communication and case-interview performance remain the primary rejection drivers (56% combined).',
    'Emerging sectors like Data/Digital Development and Climate require faster curriculum adaptation.'
  ];

  const strategicPriorities = [
    'Mandate 6-week practical Excel → Power BI → SQL analytics bootcamp prior to placement drives.',
    'Formulate strategic account plans for top 10 development-sector repeat hiring partners.',
    'Institute alumni-guided mock case interview panels targeting high-CTC CSR and consulting roles.'
  ];

  const whatIsWorking = [
    'Over 94% placement rate achieved in primary development-sector streams.',
    'Strong institutional partnerships with premier government & development entities like BRLPS/JEEViKA, CARE India, and AKRSP.',
    'High engagement in rural development and livelihoods domain subjects.'
  ];

  const whatNeedsAttention = [
    'Uneven technical proficiency in Excel and data visualization tools across students.',
    'Final-round interview conversion sits at 32%, indicating interview-stage bottlenecks.',
    'Limited alumni referral mapping in expanding CSR and impact consulting sectors.'
  ];

  const whatToDoNext = [
    'Roll out intensive Excel and Case Analysis workshops immediately.',
    'Schedule Pre-Placement Talks (PPTs) with key repeat recruiters 4 weeks earlier.',
    'Leverage senior alumni network in Sattva, Tata Trusts, and Digital Green for direct campus referrals.'
  ];

  const summary: ExecutiveSummary = {
    kpis: {
      placement_rate: placementRate,
      placement_rate_yoy: 4.2,
      students_placed: studentsPlaced,
      students_total: studentsTotal,
      active_recruiters: activeRecruiters,
      new_recruiters: newRecruiters,
      avg_ctc_lpa: avgCTC,
      median_ctc_lpa: medianCTC,
      repeat_recruiter_rate: repeatRecruiterRate,
      interview_conversion: interviewConversion,
      critical_skill_gaps: criticalSkillGaps
    },
    diagnostics: {
      strengths,
      watch_areas: watchAreas,
      strategic_priorities: strategicPriorities
    },
    what_is_working: whatIsWorking,
    what_needs_attention: whatNeedsAttention,
    what_to_do_next: whatToDoNext
  };

  return {
    students,
    recruiters,
    skills,
    sectorTrends: SECTOR_TRENDS,
    rejectionData: INTERVIEW_REJECTION_DATA,
    courseAlignments: COURSE_ALIGNMENTS,
    alumniRecords: ALUMNI_RECORDS,
    recommendations: STRATEGIC_RECOMMENDATIONS,
    dataQualityIssues: DATA_QUALITY_ISSUES,
    summary
  };
}
